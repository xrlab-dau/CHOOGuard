# CHOOGuard 클린 스타트 에픽·구현 명세 v2

**기준:** 2026-09-19 / 빈 저장소에서 새로 구축 / 원격 초기화·코드 변경은 수행하지 않음.

**결정:** 이전 에픽을 유지하지 않는다. 새 프로젝트 부팅부터 도메인·영속운영·native RTS·분기·물리·대본·검증·배포까지 새 산출물로 연결한다. 기존 제품 요구와 외부 연구는 활용하지만 과거 코드·API·구역 ID·이슈를 입력으로 요구하지 않는다.

## 새 에픽

| 에픽 | 책임 | 작업 수 |
|---|---|---:|
| [CS-BOOT](epics/CS-BOOT.md) | 새 Unity 제품의 부팅·입력·빌드 기반 | 3 |
| [CS-PACK](epics/CS-PACK.md) | 현장·기관 매뉴얼·자료 패키지 제작 | 4 |
| [CS-OPS](epics/CS-OPS.md) | 영속 상태를 가진 다기관 운영 커널 | 6 |
| [CS-WORLD](epics/CS-WORLD.md) | 현실 기반 철도 운영 공간 | 4 |
| [CS-PLAY](epics/CS-PLAY.md) | Unity 네이티브 RTS 운영 작업공간 | 5 |
| [CS-LAB](epics/CS-LAB.md) | 저장된 운영안의 분기·비교 실험 | 4 |
| [CS-MODES](epics/CS-MODES.md) | 매뉴얼 교육과 제약 기반 랜덤 실험 | 3 |
| [CS-SIM](epics/CS-SIM.md) | 다중 물리·행동 계산과 정량 검증 | 5 |
| [CS-SCRIPT](epics/CS-SCRIPT.md) | 선택 운영안의 근거 기반 대본 저작 | 4 |
| [CS-PROOF](epics/CS-PROOF.md) | 사용자 가치·현장 적합성 검증 | 4 |
| [CS-SHIP](epics/CS-SHIP.md) | 로컬 배포·복구·현장 확장 | 3 |

## 첫 구현 순서와 병행 경계

1. **CS-BOOT.01–.02:** 새 Unity 프로젝트, package lock, boot, assembly와 공개 ports를 만든다. CS-PROOF.01의 실제 사용자 조사는 별도로 시작할 수 있으며 구현을 가로막지 않는다.
2. **CS-PACK.01 + CS-OPS.01–.02:** 새 도메인 입력과 run, 영속 명령·예약을 만든다. 저장이 운영 커널 안에 있으므로 저장 에픽과 코어 에픽의 상호 완료대기가 없다.
3. **CS-WORLD.01 + CS-PLAY.01–.02:** 새 2공간 fixture에 native UI를 연결한다. 계약 안정 뒤 각자 test double로 제작하고 통합에는 실제 커널을 사용한다.
4. **CS-OPS.03–.06 + CS-PLAY 나머지:** 두 기관의 권한·정보·업무·원인 분석을 완성한다. 시각 자산·실제 현장 입력은 독립 경로로 보완한다.
5. **CS-LAB + CS-MODES + CS-SCRIPT:** 원본 불변 A/B, 동일 코어의 두 모드, 근거·조건부 대본을 연결한다. 새로운 인계 산출물 단위로 합친다.
6. **CS-SIM:** worker 계약은 초기에 병행하고 필요한 실제 현상을 순차 연결한다. 모든 solver가 모든 UI의 선행은 아니다. 정량 주장은 해당 현상과 독립 자료가 있어야 한다.
7. **CS-PROOF + CS-SHIP:** 제품 실행, 실제 사용자 효용, 지정 현장 정확도, 기관 수용, 배포·복구를 다른 증거로 판단한다.

번호는 시간·장비·사람의 강제 배정이 아니다. 정확한 선행 task·artifact·소비단계·조건은 `contracts/tasks.json`에 있다.

## 수용 지점

| 단계 | 수용 결과 | 금지하는 과장 |
|---|---|---|
| NEW-BOOT | 빈 프로젝트에서 native Player 부팅·테스트 | 과거 성공 로그 재사용 |
| FIRST-OPERATION | 실제 저장과 native UI로 한 공조 업무 수행 | 버튼 클릭을 업무 완료로 취급 |
| AUTHORING-LOOP | A 보존→B 수정→비교→대본→새 run | replay를 새 실험으로 취급 |
| USER-VALUE | 실제 과제의 총인시·품질·중단·도움 포함 평가 | UI 선호로 시간절감/안전성 주장 |
| NAMED-USE | 현장·사건·모델·QoI·기관별 수용 | 미지원 현상에 승인 확장 |
| RELEASE | 오프라인 설치·복구·새 현장 확장 | 깨끗한 새 PC 시험 없이 배포완료 |

**검증 상태:** 아래 명세와 연결 제품 인수시험은 모두 NOT_RUN이다. 문서 검사 통과와 구현·현장 수용은 다르다.
