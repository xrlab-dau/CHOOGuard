# CHOOGuard — 빈 저장소에서 새 구축

## 시작 규칙
제품 방향은 유지하고 에픽·작업·경로·구역 ID·빌드·검증은 새로 만든다. 현재 첫 작업은 **CS-BOOT.01**이다. 과거 코드나 문맥 CLI가 필요하지 않다. 원격 초기화·삭제·force push는 이 문서의 실행 범위가 아니다.

## 읽기 순서
1. `RESET_DECISIONS.md`와 `PRODUCT_BASELINE.md`.
2. `EPICS.md`에서 현재 작업을 선택.
3. `CONTRACTS.md`와 `tasks/CS-BOOT.01.json` 등 지정 작업.
4. 해당 입력/원문만 `reference/`에서 조회.

## 문서 확인 명령
```sh
python tools/check_plan.py
python -m unittest discover -s tests -v
python tools/task_context.py CS-BOOT.01
```
표준 Python 라이브러리만 사용한다. 이 명령은 문서 검사·조회이며 Unity 프로젝트 생성·빌드·작업 배정을 수행하지 않는다. 아직 Unity 제품 코드를 제공하거나 컴파일한 상태가 아니다.

## 첫 실제 개발 산출물
새 Unity 프로젝트·정확 editor/package lock·native boot·새 assembly/ports·실행 결과. 이어 새 두 기관 입력과 영속 명령/예약, 두 공간 fixture의 native 명령 UI를 구현한다. 최신 실제 원본과 기관 검수는 해당 현장 수용의 입력이며 합성 기술개발을 전역 차단하지 않는다.

## 유효한 완료 보고
새 commit/경로, 사용한 입력과 실제 hash, 실제 실행 명령과 원시 결과, 실패·미실행, 후행 산출물을 남긴다. 소스 후보·문서의 체크박스를 제품 PASS로 바꾸지 않는다.
