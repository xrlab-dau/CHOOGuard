# CHOOGuard 클린 스타트 에픽·구현 명세 v2

**기준:** 2026-09-19 / 빈 저장소에서 새로 구축 / 원격 초기화·코드 변경은 수행하지 않음.

**결정:** 이전 에픽을 유지하지 않는다. 새 프로젝트 부팅부터 도메인·영속운영·native RTS·분기·물리·대본·검증·배포까지 새 산출물로 연결한다. 기존 제품 요구와 외부 연구는 활용하지만 과거 코드·API·구역 ID·이슈를 입력으로 요구하지 않는다.

## 새 에픽

| 에픽 | 책임 | 작업 수 |
|---|---|---:|
| [CS-BOOT](epics/CS-BOOT.md) | 새 Unity 제품의 부팅·입력·빌드 기반 | 3 |
| [CS-PACK](epics/CS-PACK.md) | 현장·기관 매뉴얼·자료 패키지 제작 | 4 |
| [CS-OPS](epics/CS-OPS.md) | 영속 상태를 가진 다기관 운영 커널 | 6 |
| [CS-WORLD](epics/CS-WORLD.md) | 현실 기반 철도 운영 공간 | 4 |
| [CS-PLAY](epics/CS-PLAY.md) | Unity 네이티브 RTS 운영 작업공간 | 5 |
| [CS-LAB](epics/CS-LAB.md) | 저장된 운영안의 분기·비교 실험 | 4 |
| [CS-MODES](epics/CS-MODES.md) | 매뉴얼 교육과 제약 기반 랜덤 실험 | 3 |
| [CS-SIM](epics/CS-SIM.md) | 다중 물리·행동 계산과 정량 검증 | 5 |
| [CS-SCRIPT](epics/CS-SCRIPT.md) | 선택 운영안의 근거 기반 대본 저작 | 4 |
| [CS-PROOF](epics/CS-PROOF.md) | 사용자 가치·현장 적합성 검증 | 4 |
| [CS-SHIP](epics/CS-SHIP.md) | 로컬 배포·복구·현장 확장 | 3 |

## 첫 구현 순서와 병행 경계

1. **CS-BOOT.01–.02:** 새 Unity 프로젝트, package lock, boot, assembly와 공개 ports를 만든다. CS-PROOF.01의 실제 사용자 조사는 별도로 시작할 수 있으며 구현을 가로막지 않는다.
2. **CS-PACK.01 + CS-OPS.01–.02:** 새 도메인 입력과 run, 영속 명령·예약을 만든다. 저장이 운영 커널 안에 있으므로 저장 에픽과 코어 에픽의 상호 완료대기가 없다.
3. **CS-WORLD.01 + CS-PLAY.01–.02:** 새 2공간 fixture에 native UI를 연결한다. 계약 안정 뒤 각자 test double로 제작하고 통합에는 실제 커널을 사용한다.
4. **CS-OPS.03–.06 + CS-PLAY 나머지:** 두 기관의 권한·정보·업무·원인 분석을 완성한다. 시각 자산·실제 현장 입력은 독립 경로로 보완한다.
5. **CS-LAB + CS-MODES + CS-SCRIPT:** 원본 불변 A/B, 동일 코어의 두 모드, 근거·조건부 대본을 연결한다. 새로운 인계 산출물 단위로 합친다.
6. **CS-SIM:** worker 계약은 초기에 병행하고 필요한 실제 현상을 순차 연결한다. 모든 solver가 모든 UI의 선행은 아니다. 정량 주장은 해당 현상과 독립 자료가 있어야 한다.
7. **CS-PROOF + CS-SHIP:** 제품 실행, 실제 사용자 효용, 지정 현장 정확도, 기관 수용, 배포·복구를 다른 증거로 판단한다.

번호는 시간·장비·사람의 강제 배정이 아니다. 정확한 선행 task·artifact·소비단계·조건은 `contracts/tasks.json`에 있다.

## 수용 지점

| 단계 | 수용 결과 | 금지하는 과장 |
|---|---|---|
| NEW-BOOT | 빈 프로젝트에서 native Player 부팅·테스트 | 과거 성공 로그 재사용 |
| FIRST-OPERATION | 실제 저장과 native UI로 한 공조 업무 수행 | 버튼 클릭을 업무 완료로 취급 |
| AUTHORING-LOOP | A 보존→B 수정→비교→대본→새 run | replay를 새 실험으로 취급 |
| USER-VALUE | 실제 과제의 총인시·품질·중단·도움 포함 평가 | UI 선호로 시간절감/안전성 주장 |
| NAMED-USE | 현장·사건·모델·QoI·기관별 수용 | 미지원 현상에 승인 확장 |
| RELEASE | 오프라인 설치·복구·새 현장 확장 | 깨끗한 새 PC 시험 없이 배포완료 |

**검증 상태:** 아래 명세와 연결 제품 인수시험은 모두 NOT_RUN이다. 문서 검사 통과와 구현·현장 수용은 다르다.


---

# CS-BOOT — 새 Unity 제품의 부팅·입력·빌드 기반

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 빈 저장소에서 반복 가능한 native PC 실행본을 만든다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** Unity 프로젝트 신규 생성 / 패키지·렌더·스크립팅 backend 고정 / 도메인/표현 assembly 경계 / EditMode·PlayMode·Player 실행 경로

**종료 조건:** 새 checkout에서 프로젝트 열기·컴파일·부팅 재현 / 필수 패키지와 로컬 의존성 명시 / 과거 프로젝트·사설 로컬 경로 없이 실행

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-BOOT.01 | 새 프로젝트·의존성 잠금 | IMPLEMENTATION |

| CS-BOOT.02 | assembly 경계와 신규 공개 계약 | IMPLEMENTATION |

| CS-BOOT.03 | 새 테스트·빌드 실행 경로 | IMPLEMENTATION |



## CS-BOOT.01 · 새 프로젝트·의존성 잠금

**산출물:** `A-CS-BOOT.01` — 새 Unity 프로젝트, boot scene, 정확한 editor/package lock, 최초 실행 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** BuildBaseline {editorVersion, packageLockSha256, renderPipeline, backend, os, nativePlugins, buildReceiptRef}; 모든 값은 새 실행에서 기록.

**관련 제품 요구:** REQ-066

### 만들 파일과 시험

- `ProjectSettings/ProjectVersion.txt`
- `ProjectSettings/GraphicsSettings.asset`
- `Packages/manifest.json`
- `Packages/packages-lock.json`
- `Assets/ChooGuard/Scenes/Bootstrap.unity`
- `docs/build/baseline.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/BOOT/Boot01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

선행 제품 산출물 없음. 초기화를 실행하는 명령이나 과거 자료를 요구하지 않는다.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. Unity 6 LTS 계열의 URP 3D 프로젝트를 비어 있는 작업 폴더에 생성한다. 정확한 패치·OS·backend는 설치된 정식 조합으로 선택해 기록한다.

2. uGUI/TMP·Input System·Test Framework를 새로 확인/도입하고 전체 lock을 커밋한다. 한글 font asset은 공급경로만 기록하고 이 명세에 폰트 바이너리를 넣지 않는다.

3. Bootstrap에는 하나의 composition root와 EventSystem만 두고 default font·missing shader·입력 모듈 상태를 검사한다.

```

### 정상·반례 시험

**TEST-CS-BOOT.01-P / NOT_RUN**

Given 이전 프로젝트가 없는 작업 폴더  
When Unity에서 생성·열기·native PC build  
Then 패키지가 해결되고 부팅하며 정확 버전이 새 기록에 남는다.

**TEST-CS-BOOT.01-N / NOT_RUN**

Given 다른 PC 전용 DLL 경로 또는 해결되지 않은 패키지  
When 새 checkout에서 build  
Then 환경 오류로 실패를 보고하고 이전 실행본이나 성공 로그를 복사하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-BOOT.02 · assembly 경계와 신규 공개 계약

**산출물:** `A-CS-BOOT.02` — Contracts·Domain·Application·Presentation의 신규 참조 방향과 typed ports

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** IOperationsPort: Preview(intent), Submit(intent), ReadReceipt(runId,intentId), ReadProjection(view); 실제 완료는 후속 event.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/ChooGuard.Contracts.asmdef`
- `Assets/ChooGuard/Domain/ChooGuard.Domain.asmdef`
- `Assets/ChooGuard/Application/ChooGuard.Application.asmdef`
- `Assets/ChooGuard/Presentation/ChooGuard.Presentation.asmdef`
- `Assets/ChooGuard/Contracts/OperationsPorts.cs`
- `Assets/ChooGuard/App/CompositionRoot.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/BOOT/Boot02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.01.candidate`의 `A-CS-BOOT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. Contracts와 Domain은 UnityEngine에 의존하지 않는 경계로 만든다. 저장과 계산은 port로 연결한다.

2. CommandIntent, CommandReceipt, SessionProjection, IOperationsPort를 CONTRACTS.md의 신규 모델대로 정의한다.

3. CompositionRoot는 한 run당 한 state writer를 생성한다. 각 외부 worker는 별도 기능을 확인하기 전 생성하지 않는다.

```

### 정상·반례 시험

**TEST-CS-BOOT.02-P / NOT_RUN**

Given 새 assembly 집합  
When 참조 그래프와 compile 검사  
Then Domain에서 Unity API·UI 타입을 참조하지 않으며 boot에서 동일 계약의 test double을 연결한다.

**TEST-CS-BOOT.02-N / NOT_RUN**

Given Domain이 HUD 컴포넌트를 참조  
When assembly 검사  
Then 의존성 위반이 탐지되고 빌드 gate가 실패한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-BOOT.03 · 새 테스트·빌드 실행 경로

**산출물:** `A-CS-BOOT.03` — EditMode·PlayMode·Player 실행과 원시 결과 보존 명령

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TestReceipt {testSet, commit, environment, startedAt, command, resultFiles, status, notRunReason}; CI credential은 저장소에 넣지 않는다.

**관련 제품 요구:** REQ-061

### 만들 파일과 시험

- `scripts/Run-UnityTests.ps1`
- `scripts/Build-Player.ps1`
- `.github/workflows/verify.yml`
- `Assets/ChooGuard/Tests/EditMode/ChooGuard.EditModeTests.asmdef`
- `Assets/ChooGuard/Tests/PlayMode/ChooGuard.PlayModeTests.asmdef`

- 검사: `Assets/ChooGuard/Tests/EditMode/BOOT/Boot03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.01.candidate`의 `A-CS-BOOT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. UNITY_EDITOR_PATH와 PROJECT_PATH를 입력받아 Test Framework를 실행하고 결과 XML·로그·exit code를 보존한다.

2. 라이선스/장치가 없는 CI는 미실행으로 실패 또는 중립 상태를 명시하고 임의 PASS를 만들지 않는다.

3. 일반 compile smoke와 Player의 렌더·IME·입력·디스크 시험을 분리한다.

```

### 정상·반례 시험

**TEST-CS-BOOT.03-P / NOT_RUN**

Given 실행 가능한 Unity editor와 한 실패 시험  
When 테스트 스크립트 실행  
Then 실패 exit code와 NUnit XML이 전달된다.

**TEST-CS-BOOT.03-N / NOT_RUN**

Given editor 실행파일 부재  
When 같은 스크립트 실행  
Then NOT_RUN과 필요한 환경을 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

---

# CS-PACK — 현장·기관 매뉴얼·자료 패키지 제작

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 근거가 있는 콘텐츠를 실행 규칙과 새 공간 식별자로 구조화한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 새 식별자·단위·시간·자격 스키마 / RuleBundle 및 적용성 검수 / 무료 원본 입고 등록 / 새 SiteBundle·관측/가상 분리

**종료 조건:** 같은 이름의 다른 시설·기관을 구별 / 출처의 발견/취득/검사/수용 구분 / 실물 입력이 없는 기술 시험용 콘텐츠를 명확히 표시

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-PACK.01 | 새 공간·기관·시간·데이터 식별자 | IMPLEMENTATION |

| CS-PACK.02 | 기관 매뉴얼을 검수 가능한 규칙으로 구성 | IMPLEMENTATION |

| CS-PACK.03 | 무료 원본 입고와 파일 신뢰경계 | IMPLEMENTATION |

| CS-PACK.04 | 실제 현장 입력·현실 관측 갱신 | IMPLEMENTATION |



## CS-PACK.01 · 새 공간·기관·시간·데이터 식별자

**산출물:** `A-CS-PACK.01` — 새 namespace의 도메인 DTO와 schema·합성 입력

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SiteBundle {id,revision,frames,regions,portals,entities,sourceRefs,qualification}; ScenarioSpec와 OperationalPlan은 별도 revision.

**관련 제품 요구:** REQ-015, REQ-060

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/ContentTypes.cs`
- `Assets/ChooGuard/Content/ContentValidator.cs`
- `content/schemas/site.schema.json`
- `content/schemas/scenario.schema.json`
- `content/fixtures/two-agency.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 stable ID를 발급하고 표시 이름과 분리한다. 구역 수·ID 집합은 실제 목표 범위로 정의하며 과거 ID 목록을 요구하지 않는다.

2. SI 단위, 좌표 frame, simulation tick, event sequence, authored/observed/received 시간을 분리한다.

3. SiteBundle·ScenarioSpec·OperationalPlan의 참조/버전을 검사하고 원본을 immutable로 보관한다.

```

### 정상·반례 시험

**TEST-CS-PACK.01-P / NOT_RUN**

Given 이름이 같고 ID가 다른 두 기관  
When 콘텐츠 등록  
Then 고유 ID로 서로 구분하며 역 이름만으로 병합하지 않는다.

**TEST-CS-PACK.01-N / NOT_RUN**

Given 정의되지 않은 구역 ID 또는 음수 수량  
When 실행 입력 검사  
Then 필드 경로를 포함해 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [STD-JSONLD: JSON-LD 1.1](https://www.w3.org/TR/json-ld11/)

- [STD-PROV: PROV-O](https://www.w3.org/TR/prov-o/)



## CS-PACK.02 · 기관 매뉴얼을 검수 가능한 규칙으로 구성

**산출물:** `A-CS-PACK.02` — RuleBundle과 판본·적용성·예외·검토 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** RuleClause {id,revision,kind,scope,guard,effect,handoff,exception,sourceLocator,review}; DTO는 예외를 검토자료로 유지.

**관련 제품 요구:** REQ-031, REQ-033, REQ-034

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/RuleTypes.cs`
- `Assets/ChooGuard/Content/RuleCatalog.cs`
- `content/schemas/rule.schema.json`
- `content/rules/catalog.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 원문 locator·판본·기관·상황·단위·조건·권한·효과·인계·예외를 필드로 만든다.

2. REQUIRED, DISCRETIONARY, ADVISORY, INVARIANT, UNKNOWN을 구분한다.

3. 승인 주체와 revision 결속이 없는 후보는 official rule로 활성화하지 않는다. 규칙 변경은 의존 초안의 자격만 만료시킨다.

```

### 정상·반례 시험

**TEST-CS-PACK.02-P / NOT_RUN**

Given 검수된 규칙과 특정 기관·상황  
When bundle 활성화  
Then 일치하는 규칙만 실행하고 적용근거를 제공한다.

**TEST-CS-PACK.02-N / NOT_RUN**

Given 판본이 없는 원문 요약  
When 공식 규칙 등록 요청  
Then DRAFT로 남기며 모델이 권한이나 시간을 채우지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-KORAIL: 코레일 재난관리체계](https://info.korail.com/info/contents.do?key=969)

- [MAN-MEDICAL: 재난응급의료 비상대응매뉴얼 개정·배포](https://www.mohw.go.kr/board.es?act=view&bid=0009&list_no=1478957&mid=a10402000000&nPage=1&tag=)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-PACK.03 · 무료 원본 입고와 파일 신뢰경계

**산출물:** `A-CS-PACK.03` — 원본 manifest·비용·형식·hash·입고 상태

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** AssetReceipt {id,sourceUrl,tier,rawHash,formats,rigClips,parts,importStatus,limits}; 실제 바이너리가 없으면 rawHash=null.

**관련 제품 요구:** REQ-062, REQ-063, REQ-064

### 만들 파일과 시험

- `Assets/ChooGuard/Content/AssetIntakeValidator.cs`
- `sources/assets/catalog.json`
- `sources/assets/receipts.schema.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 무료판별 파일 목록을 확인하고 원본은 격리 경로에서 hash·크기·압축경로·실행코드 유무를 검사한다.

2. 페이지 확인과 원본 취득·Unity 임포트·현장 수용을 다른 필드로 둔다.

3. 표현용 기하에서 정원·물성·능력을 추론하지 않는다. 실제 무료 다운로드 상태는 새 환경에서 재확인한다.

```

### 정상·반례 시험

**TEST-CS-PACK.03-P / NOT_RUN**

Given 무료 모델 archive와 취득 영수증  
When 입고 등록  
Then 원문·파일 hash·형식·tier·후속 검사가 분리된다.

**TEST-CS-PACK.03-N / NOT_RUN**

Given archive 안의 경로이탈/임의 DLL  
When 자동 입고  
Then 격리·거부하고 실행하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [FREE-001: Free Low Poly Vehicles Pack](https://rgsdev.itch.io/free-low-poly-vehicles-pack)

- [FREE-010: Animated Men Pack](https://quaternius.com/packs/animatedmen.html)

- [FREE-011: Animated Women Pack](https://quaternius.com/packs/animatedwomen.html)

- [FREE-018: Korean Fire Extinguisher 01](https://polyhaven.com/a/korean_fire_extinguisher_01)

- [MAT-BIPA-BUSAN3: 부산 디지털로케이션 제3구역](https://bwebtoon.com/webtoon-home/core-businesses/digital-location/)

- [MAT-KTX-I: KTX-I OpenBVE 원본](https://haesangang-0317.tistory.com/268)



## CS-PACK.04 · 실제 현장 입력·현실 관측 갱신

**산출물:** `A-CS-PACK.04` — 첫 현장 자료 패키지와 baseline/가상 분리 규칙

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Observation {targetId,observedAt,receivedAt,value,unit,sourceHash,quality}; 현실 자료 없음은 기술 개발의 전역 blocker가 아님.

**관련 제품 요구:** REQ-050

### 만들 파일과 시험

- `content/sites/first-site/source-manifest.json`
- `content/sites/first-site/observation-policy.json`
- `Assets/ChooGuard/Content/RealityBaselineUpdater.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 허용된 공간·독립 기준 치수·기관 역할·작업시간 근거를 수집하고 관측/문헌/가정을 분리한다.

2. 관측 시간·수신 시간·대상 revision을 검사한다. 역순 갱신은 최신값을 조용히 덮지 않는다.

3. 가상 문 개방·훈련 사건을 실제 시설 관측으로 저장하지 않는다. 갱신한 SiteBundle은 새 revision을 만든다.

```

### 정상·반례 시험

**TEST-CS-PACK.04-P / NOT_RUN**

Given 현재 시설과 이후의 허용된 실제 관측  
When baseline 갱신  
Then 현장 revision과 변경근거가 남고 과거 run은 원 버전을 참조한다.

**TEST-CS-PACK.04-N / NOT_RUN**

Given 운영 플레이의 가상 문 개폐 이벤트  
When 현실 관측으로 주입  
Then 원천 종류 불일치로 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-KORAIL: 코레일 재난관리체계](https://info.korail.com/info/contents.do?key=969)

- [STD-DTC: Definition of a Digital Twin](https://www.digitaltwinconsortium.org/initiatives/the-definition-of-a-digital-twin/)

- [STD-SOSA: SOSA/SSN](https://www.w3.org/TR/vocab-ssn/)

---

# CS-OPS — 영속 상태를 가진 다기관 운영 커널

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 요청·권한·자원·업무·보고의 실제 상태변화를 한 권위자로 실행한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 명령 계약·단일 writer / SQLite·원자 예약·outbox / 기관 권한/지원요청 / 업무망·지식·다축 원인

**종료 조건:** 저장 전 성공 응답 없음 / 중복 예약과 요청 재적용 없음 / 기관 수신 정보와 작성자 전체 분석 분리

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-OPS.01 | 신규 run·단일 writer·명령 상태머신 | IMPLEMENTATION |

| CS-OPS.02 | SQLite 저장·원자 예약·outbox | IMPLEMENTATION |

| CS-OPS.03 | 기관 권한·지원요청·인계 | IMPLEMENTATION |

| CS-OPS.04 | 기관별 정보·보고·인계 상태 | IMPLEMENTATION |

| CS-OPS.05 | 업무 의존·공간 접근·예약 생명주기 | IMPLEMENTATION |

| CS-OPS.06 | 다축 원인·교착·형식 모델 대조 | IMPLEMENTATION |



## CS-OPS.01 · 신규 run·단일 writer·명령 상태머신

**산출물:** `A-CS-OPS.01` — fresh OperationsSession과 미리보기/접수/조회 포트

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** CommandIntent→CommandReceipt, stateVersion/readSet; 수락은 수행완료와 다르다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Application/OperationsSession.cs`
- `Assets/ChooGuard/Application/CommandDispatcher.cs`
- `Assets/ChooGuard/Domain/RunState.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. run별 mailbox와 single-writer queue를 만들고 순서는 simulation tick·priority·monotonic sequence로 고정한다.

2. Preview는 side effect 없이 현재 guard를 평가한다. Submit은 requester와 acting team을 구분해 재검사한다.

3. 같은 key+payload는 같은 receipt, 다른 payload는 INTENT_CONFLICT를 반환한다. 인메모리 double은 기능시험 전용이다.

```

### 정상·반례 시험

**TEST-CS-OPS.01-P / NOT_RUN**

Given 같은 intentId·payload 두 번  
When 명령 제출  
Then 논리 변경 1회와 동일 receipt를 돌려준다.

**TEST-CS-OPS.01-N / NOT_RUN**

Given preview 이후 대상 revision 변경  
When submit  
Then STALE_READSET이며 업무 상태를 바꾸지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-OPS.02 · SQLite 저장·원자 예약·outbox

**산출물:** `A-CS-OPS.02` — 영속 commit과 자원 예약을 동일 경계에서 처리하는 기반

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** IRunStore.Commit(CommitBatch)→CommitReceipt; CommitBatch includes expectedRevision,events,reservations,receipt,outbox; 원본 append-only.

**관련 제품 요구:** REQ-024, REQ-071

### 만들 파일과 시험

- `Assets/ChooGuard/Persistence/SqliteRunStore.cs`
- `Assets/ChooGuard/Persistence/SqliteProvider.cs`
- `Assets/ChooGuard/Persistence/Schema.sql`
- `Assets/ChooGuard/Domain/ReservationPlanner.cs`
- `Assets/ChooGuard/Application/OutboxDispatcher.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.01.candidate`의 `A-CS-OPS.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 대상 Unity Player의 managed/native SQLite 조합을 smoke-test하고 pin한다. 플랫폼별 P/Invoke 성공을 확인한다.

2. BEGIN IMMEDIATE 경계에서 run revision·현재 자원 가용량을 재검사한다. 팀 구성원·승무원은 고유 ID로 중복점유를 검사한다.

3. 이벤트·예약·receipt·projection revision·outbox를 원자적으로 저장하고 commit 성공 뒤에만 acceptance를 게시한다.

4. 외부 전달은 재시도 가능하지만 jobId/resultId로 멱등 적용한다. 디스크 실패 후 candidate 메모리 상태를 게시하지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.02-P / NOT_RUN**

Given 팀·차량·장비를 모두 요구하고 모두 가용  
When 배정 commit  
Then 모든 예약과 receipt가 함께 기록되고 재시작 후 복원된다.

**TEST-CS-OPS.02-N / NOT_RUN**

Given 장비 하나 부족 또는 commit 직전 저장 실패  
When 복합 배정  
Then 새 예약은 0개, 기존 예약은 유지, 성공 응답은 없음.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-TAPAAL: TAPAAL](https://www.tapaal.net/features/)



## CS-OPS.03 · 기관 권한·지원요청·인계

**산출물:** `A-CS-OPS.03` — 명령 scope와 기관 간 협조를 분리한 권한 정책

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** AuthorityGrant {holder,agency,scope,revision,ruleRef}; RequestSupport와 AssignTask는 구별.

**관련 제품 요구:** REQ-021, REQ-022

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/AuthorityPolicy.cs`
- `Assets/ChooGuard/Domain/SupportRequest.cs`
- `Assets/ChooGuard/Domain/HandoverPolicy.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.02.candidate`의 `A-CS-OPS.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 작성자의 가상 설계권과 기관의 업무권을 구분한다.

2. 기관내 지시와 기관간 요청은 서로 다른 event로 처리한다.

3. 인계에는 원 권한 revision·범위·상대 확인·사유를 요구하며 후착 도착 자체는 전역 권한을 바꾸지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.03-P / NOT_RUN**

Given 유효한 scope의 인계가 완료됨  
When 새 담당자의 범위내 지시  
Then 해당 범위에만 권한 변경이 적용된다.

**TEST-CS-OPS.03-N / NOT_RUN**

Given 타기관 유닛에 직접 명령 또는 오래된 인계 revision  
When 지시 제출  
Then 권한거부/충돌과 적용 규칙 근거를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-KORAIL: 코레일 재난관리체계](https://info.korail.com/info/contents.do?key=969)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-OPS.04 · 기관별 정보·보고·인계 상태

**산출물:** `A-CS-OPS.04` — 보고의 생성/송신/수신/확인/적용과 지식 projection

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Message {id,sender,recipient,observedTick,receivedTick,expiry,payloadRef,ack}; projection은 read-only.

**관련 제품 요구:** REQ-011, REQ-027, REQ-028

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/MessageLifecycle.cs`
- `Assets/ChooGuard/Domain/KnowledgeState.cs`
- `Assets/ChooGuard/Application/AgencyProjection.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.03.candidate`의 `A-CS-OPS.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. messageId·관측시각·전달상태·TTL·수신기관을 기록한다.

2. 중복은 같은 의미효과를 재적용하지 않고 역순·상충 보고는 UNKNOWN/CONFLICTED 상태로 남긴다.

3. 작성자 전체 분석 projection이 기관 knowledge를 수정하지 못하게 한다. 미래 상태를 과거 복기의 지식으로 사용하지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.04-P / NOT_RUN**

Given 발송했지만 수신 전인 보고  
When 기관별 조회  
Then 발신자는 송신 상태, 수신자는 미수신 상태를 본다.

**TEST-CS-OPS.04-N / NOT_RUN**

Given 최신 보고 뒤 도착한 오래된 보고  
When 처리  
Then 최신값을 덮지 않고 과거/상충 근거로 보존한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-OPS.05 · 업무 의존·공간 접근·예약 생명주기

**산출물:** `A-CS-OPS.05` — 시간·자원·능력·정보 조건에 반응하는 운영 workflow

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TaskState {lifecycle,guards,reasons,reservations,outcome,handoff}; GuardResult는 truth/status와 evidence refs를 가진다.

**관련 제품 요구:** REQ-012, REQ-023, REQ-025, REQ-026, REQ-029, REQ-045

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/WorkflowEngine.cs`
- `Assets/ChooGuard/Domain/ResourceLifecycle.cs`
- `Assets/ChooGuard/Domain/TaskConditions.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops05Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.04.candidate`의 `A-CS-OPS.04` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 요청→배정→준비/이동→수행→보고/인계→반환 중 업무별 필요한 단계를 명시한다.

2. 작업 소요시간은 근거가 있는 조건부 입력으로 받는다. 합성 값은 검증된 현장 예측과 분리한다.

3. 팀 분리/결합·취소·교대·재보급은 능력과 자원 점유를 다시 검사한다. 수용·의료 인계는 운영상태이며 임상 판단을 생성하지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.05-P / NOT_RUN**

Given 선행 업무와 수신확인·자원·접근 조건이 모두 충족  
When 업무 시작 평가  
Then 한 번만 시작하며 완료/보고/재가용을 별개로 기록한다.

**TEST-CS-OPS.05-N / NOT_RUN**

Given 업무 완료됐으나 회복/재보급 조건 미충족  
When 즉시 재배정  
Then 대기 이유와 가용 조건을 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-MEDICAL: 재난응급의료 비상대응매뉴얼 개정·배포](https://www.mohw.go.kr/board.es?act=view&bid=0009&list_no=1478957&mid=a10402000000&nPage=1&tag=)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-OPS.06 · 다축 원인·교착·형식 모델 대조

**산출물:** `A-CS-OPS.06` — 권한/정보/자원/이동/안전/evidence의 원인과 wait-for 분석

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Reason {axis,code,subject,causes,evidence,resolutionConditions}; 설명 모델은 권한·결과를 변경하지 못함.

**관련 제품 요구:** REQ-013, REQ-030, REQ-041

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/ReasonEngine.cs`
- `Assets/ChooGuard/Domain/WaitForAnalyzer.cs`
- `benchmarks/operations/model-projection.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops06Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 진행상태와 원인축을 별개로 출력하며 다수 원인을 보존한다.

2. wait-for graph에서 cycle을 탐지하되 외부 도착 예정/불충분 정보와 확정 교착을 구별한다.

3. TAPAAL에 투영 가능한 부분의 trace를 비교하고 timeout·범위 제한은 미검증으로 보고한다.

```

### 정상·반례 시험

**TEST-CS-OPS.06-P / NOT_RUN**

Given A가 B의 자원, B가 A의 보고를 기다림  
When 원인 분석  
Then 연결된 업무·요청·자원과 검토 가능한 cycle을 보여준다.

**TEST-CS-OPS.06-N / NOT_RUN**

Given 외부 도착이 예정된 정상 대기  
When 동일 분석  
Then 확정 교착으로 자동 판정하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-TAPAAL: TAPAAL](https://www.tapaal.net/features/)

---

# CS-WORLD — 현실 기반 철도 운영 공간

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 맵의 시각·이동·계산·의미 표현을 새로 구축한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 기술 fixture / 실제 첫 연결 구간·무료 자산 / 개체 anchor·상태 투영 / 구역 준비·로딩·차량 연결

**종료 조건:** 첫 현장의 근거/가정 분리 / 카메라·LOD가 운영결과를 바꾸지 않음 / 필요한 상태가 준비되기 전 잘못된 공간 진입 없음

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-WORLD.01 | 처음부터 만드는 2공간·문 fixture | IMPLEMENTATION |

| CS-WORLD.02 | 첫 철도 공간과 무료 시각자산 제작 | IMPLEMENTATION |

| CS-WORLD.03 | 운영 객체·월드마커·층별 보기 | IMPLEMENTATION |

| CS-WORLD.04 | 구역 준비·로딩·차량 프레임 연결 | IMPLEMENTATION |



## CS-WORLD.01 · 처음부터 만드는 2공간·문 fixture

**산출물:** `A-CS-WORLD.01` — 신규 scene·entity anchors·합성 공간 입력

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** WorldAnchorMap {entityId,transformRef,frameId,representationKind}; Unity Transform은 표시 수단.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/World/FixtureBuilder.cs`
- `Assets/ChooGuard/World/WorldEntityAnchor.cs`
- `Assets/ChooGuard/Scenes/OperationsFixture.unity`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 1m 비대칭 기준체와 두 공간·문 하나를 새 Scene에 만든다. 모든 고유 ID는 현 기준에서 발급한다.

2. visual/collider/navigation/semantic 레이어를 분리한다. 문 열림은 도메인 projection을 받아 표시한다.

3. 실측 부산역으로 표시하지 않고 SYNTHETIC_FIXTURE 라벨을 붙인다. 초기 fixture는 실제 자료 취득을 기다리지 않는다.

```

### 정상·반례 시험

**TEST-CS-WORLD.01-P / NOT_RUN**

Given 새 프로젝트와 fixture builder  
When 생성·reload  
Then ID가 중복되지 않고 문·두 공간과 단위가 재현된다.

**TEST-CS-WORLD.01-N / NOT_RUN**

Given 같은 entityId를 두 anchor에 사용  
When 검사  
Then 정확 경로를 반환하며 로드를 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-WORLD.02 · 첫 철도 공간과 무료 시각자산 제작

**산출물:** `A-CS-WORLD.02` — 외부 도착–맞이방–승강장–객실의 입고·정합 산출물

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** GeometryReceipt {assetId,sourceHash,transform,units,parts,residuals,scope}; 실제 맵 수용에는 현장 입력이 추가로 필요.

**관련 제품 요구:** REQ-014, REQ-017, REQ-018

### 만들 파일과 시험

- `Assets/ChooGuard/World/AssetImportPolicy.cs`
- `Assets/ChooGuard/World/CoordinateValidator.cs`
- `Assets/ChooGuard/Art/first-site.asset-manifest.json`
- `content/sites/first-site/geometry.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.03.candidate`의 `A-CS-PACK.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.04.candidate`의 `A-CS-PACK.04` → 이 작업 `qualification`. 조건: `NAMED_SITE_ACCURACY`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 무료 원본을 하나씩 격리 임포트하여 단위·축·rig·clip·문 피벗·LOD·재질·충돌을 검사한다.

2. 핵심 공간은 실제 자료의 근거별로 제작하고 신경복원 후보는 COLMAP 대조와 독립 치수를 함께 사용한다.

3. 관측 부족이면 합성/추정 표현과 필요한 입력을 분리한다. 독립 치수 없이 신경망 confidence를 실측 정확도로 쓰지 않는다.

```

### 정상·반례 시험

**TEST-CS-WORLD.02-P / NOT_RUN**

Given 원본과 단위/독립 치수 근거  
When 첫 구간 제작·정합  
Then 허용 오차·잔차·변환행렬·자료 상태를 함께 납품한다.

**TEST-CS-WORLD.02-N / NOT_RUN**

Given 원본에는 mm인데 m로 임포트 또는 다른 역 자료  
When 입고 검증  
Then 축척/대상 불일치로 정량 사용을 보류한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [FREE-001: Free Low Poly Vehicles Pack](https://rgsdev.itch.io/free-low-poly-vehicles-pack)

- [FREE-003: Train Kit](https://kenney.nl/assets/train-kit)

- [FREE-018: Korean Fire Extinguisher 01](https://polyhaven.com/a/korean_fire_extinguisher_01)

- [MAT-BIPA-BUSAN3: 부산 디지털로케이션 제3구역](https://bwebtoon.com/webtoon-home/core-businesses/digital-location/)

- [MAT-KTX-I: KTX-I OpenBVE 원본](https://haesangang-0317.tistory.com/268)

- [TECH-MAPANYTHING: MapAnything: Universal Feed-Forward Metric 3D Reconstruction](https://github.com/facebookresearch/map-anything)

- [TECH-UNITY-FBX: Unity model formats](https://docs.unity3d.com/6000.3/Documentation/Manual/3D-formats.html)



## CS-WORLD.03 · 운영 객체·월드마커·층별 보기

**산출물:** `A-CS-WORLD.03` — 같은 ID의 3D 표시와 운영 projection 연결

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SessionProjection {runId,revision,viewScope,entities,reasons}; 표현 계층은 domain 상태를 직접 쓰지 않는다.

**관련 제품 요구:** REQ-016

### 만들 파일과 시험

- `Assets/ChooGuard/World/WorldProjectionApplier.cs`
- `Assets/ChooGuard/World/WorldMarkerPool.cs`
- `Assets/ChooGuard/World/FloorVisibility.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.01.candidate`의 `A-CS-OPS.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 최신 run/revision의 projection만 main thread에 반영한다. 다른 branch 결과를 적용하지 않는다.

2. 층·지붕·거리 LOD는 renderer만 바꾸고 물리/예약/지식은 바꾸지 않는다.

3. marker는 선택 우선으로 풀링하고 카메라 뒤/다른 층/기관 정보 범위를 처리한다.

```

### 정상·반례 시험

**TEST-CS-WORLD.03-P / NOT_RUN**

Given 동일 운영입력과 다른 카메라·층 보기  
When 상태 비교  
Then UI 표시 외 의미 상태는 동일하다.

**TEST-CS-WORLD.03-N / NOT_RUN**

Given 이전 branch projection 도착  
When 화면 반영  
Then 거부/무시하고 최신 상태를 유지한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-UNITY-LOAD: Unity LoadSceneAsync](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/SceneManagement.SceneManager.LoadSceneAsync.html)



## CS-WORLD.04 · 구역 준비·로딩·차량 프레임 연결

**산출물:** `A-CS-WORLD.04` — 상태를 잃지 않는 구역 및 정차 차량 연결 계약

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** RegionReadiness {regionId,visual,collision,path,state}; DockLink {vehicleFrame,siteFrame,stopConfirmed,doorState}.

**관련 제품 요구:** REQ-020

### 만들 파일과 시험

- `Assets/ChooGuard/World/RegionLoader.cs`
- `Assets/ChooGuard/World/RegionReadiness.cs`
- `Assets/ChooGuard/World/VehicleFrameBinding.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-WORLD.03.candidate`의 `A-CS-WORLD.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 작은 구간은 통째로 로드하며 확장시 additive loading을 적용한다. logical lifetime은 Scene과 분리한다.

2. 진입은 collision·경로·필수 state가 준비된 경우에만 허용한다. 로딩 실패는 해당 구간만 표시한다.

3. 정차·도킹·문 상태를 연결하며 객실 local frame과 현장 frame의 변환을 검증한다. 운행 범위는 별도 capability로 선언한다.

```

### 정상·반례 시험

**TEST-CS-WORLD.04-P / NOT_RUN**

Given 필수 데이터가 준비된 연결 구간  
When 진입·왕복·표시 unload  
Then 개체/예약/업무가 유지된다.

**TEST-CS-WORLD.04-N / NOT_RUN**

Given 차량 frame 누락 또는 바닥 미준비  
When 연결 통과  
Then 잘못된 진입을 막고 정상 구간 상태는 보존한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-UNITY-LOAD: Unity LoadSceneAsync](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/SceneManagement.SceneManager.LoadSceneAsync.html)

---

# CS-PLAY — Unity 네이티브 RTS 운영 작업공간

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 팀과 업무를 선택해 실제 명령을 제출하고 근거를 읽게 한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** uGUI·TMP·Input System 입력소유권 / RTS 선택/명령 미리보기 / HUD·카메라·월드마커 / 원인·정보·접근성·저작 오버레이

**종료 조건:** UI 뒤 월드 클릭·IME 단축키 충돌 없음 / 요청과 업무 완료를 구분 / 정밀 월드 클릭 없이 목록으로도 핵심 과업 가능

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-PLAY.01 | native 입력 소유권·IME | IMPLEMENTATION |

| CS-PLAY.02 | 팀·업무 선택과 명령 미리보기 | IMPLEMENTATION |

| CS-PLAY.03 | 게임 HUD·카메라·미니맵 | IMPLEMENTATION |

| CS-PLAY.04 | 복수 원인·기관별 정보·작업 오버레이 | IMPLEMENTATION |

| CS-PLAY.05 | 접근성·재배정·텍스트와 반복 조작 효율 | IMPLEMENTATION |



## CS-PLAY.01 · native 입력 소유권·IME

**산출물:** `A-CS-PLAY.01` — uGUI/TMP HUD와 월드/카메라 충돌 방지

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** InputOwner {context,pointerId,focus,modal}; 소비한 event를 하위 입력에 재전달하지 않는다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Input/InputContextRouter.cs`
- `Assets/ChooGuard/Presentation/Input/PointerCaptureOwner.cs`
- `Assets/ChooGuard/Presentation/Input/Operations.inputactions`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.01.candidate`의 `A-CS-BOOT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 모달→텍스트/IME→HUD→월드→카메라 순서로 입력 소유권을 고정한다.

2. pointer-down의 소유자를 up/cancel까지 유지하고 UI drag가 월드 선택으로 전환되지 않게 한다.

3. TMP 입력·IME 조합 중 Space/WASD/Esc를 game action으로 전달하지 않는다. 실제 Player에서 조합/확정/취소 시험을 한다.

```

### 정상·반례 시험

**TEST-CS-PLAY.01-P / NOT_RUN**

Given HUD 뒤에 선택 가능한 객체  
When HUD 클릭/드래그/휠  
Then UI만 반응하고 뒤 객체와 카메라는 반응하지 않는다.

**TEST-CS-PLAY.01-N / NOT_RUN**

Given 한글 입력 중 Space·Enter·Esc  
When native Player 입력  
Then 정지/재개/카메라 이벤트가 발생하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PLAY.02 · 팀·업무 선택과 명령 미리보기

**산출물:** `A-CS-PLAY.02` — RTS 선택·업무 우선 배정·혼합기관 결과 확인

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SelectionSet→CommandIntent→PreviewResult→CommandReceipt; UI 수락은 업무 완료가 아님.

**관련 제품 요구:** REQ-008, REQ-009, REQ-010

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Selection/SelectionService.cs`
- `Assets/ChooGuard/Presentation/Commands/CommandPreviewPresenter.cs`
- `Assets/ChooGuard/Presentation/Commands/CommandPreview.prefab`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.01.candidate`의 `A-CS-PLAY.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.01.candidate`의 `A-CS-OPS.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 팀·승무원 연결 차량을 기본 단위로 하고 목록/월드 선택을 같은 SelectionSet으로 연결한다.

2. 혼합기관 선택은 대상별 조건·요청/거부를 표시한다. 한 업무의 원자성 경계와 독립 업무의 부분 성공을 구분한다.

3. Submit은 명시적인 확인 뒤 수행한다. 테스트 double UI 완료와 실물 커널 통합 완료를 별도로 기록한다.

```

### 정상·반례 시험

**TEST-CS-PLAY.02-P / NOT_RUN**

Given 가용 팀과 이미 점유된 팀을 선택  
When 명령 미리보기  
Then 대상별 차이와 근거가 보이며 전체 성공처럼 표시하지 않는다.

**TEST-CS-PLAY.02-N / NOT_RUN**

Given 미리보기 뒤 자원 상태 변경  
When 제출  
Then 최신 receipt의 거부를 표시하고 UI 자체로 성공을 만들지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [GAME-EMERGENCY: EMERGENCY official](https://www.world-of-emergency.com/news/2023-09-15/234-the_new_emergency)

- [GAME-RESCUEHQ: Rescue HQ official store](https://store.playstation.com/en-us/concept/10002295)



## CS-PLAY.03 · 게임 HUD·카메라·미니맵

**산출물:** `A-CS-PLAY.03` — WorldCamera 위에 native 운영 HUD와 선택 마커

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** UIState {selection,camera,openPanels,textScale}; 운영 상태와 수명을 분리.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Hud/OperationsHud.prefab`
- `Assets/ChooGuard/Presentation/Hud/HudPresenter.cs`
- `Assets/ChooGuard/Presentation/Camera/OperationsCamera.cs`
- `Assets/ChooGuard/Presentation/Hud/MinimapPresenter.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.01.candidate`의 `A-CS-PLAY.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.03.candidate`의 `A-CS-WORLD.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. WorldCamera를 중앙으로 하고 접이식 조직 목록·inspector·command dock·timeline을 overlay canvas로 조립한다.

2. 미니맵은 실제 위치를 투영하거나 별도 camera를 사용한다. 클릭 변환은 실제 pixelRect·층·DPI를 반영한다.

3. 위치 변경 애니메이션은 receipt/물리 결과를 따라가며 업무 완료나 실제 도착의 근거가 되지 않는다.

```

### 정상·반례 시험

**TEST-CS-PLAY.03-P / NOT_RUN**

Given 실제 fixture scene과 entity projection  
When 카메라 이동·선택·minimap 조작  
Then 같은 entity와 frame으로 표시·초점이 연결된다.

**TEST-CS-PLAY.03-N / NOT_RUN**

Given 화면 비율 변경 또는 다른 층  
When 미니맵 클릭  
Then 잘못된 층/좌표로 명령을 보내지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PLAY.04 · 복수 원인·기관별 정보·작업 오버레이

**산출물:** `A-CS-PLAY.04` — 대기 사유·근거·타임라인·비교/대본 화면의 native 연결

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ReasonView/AgencyTimeline는 read-only; pause는 코어 ack 이후 표시.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Inspector/ReasonInspector.cs`
- `Assets/ChooGuard/Presentation/Timeline/AgencyTimeline.cs`
- `Assets/ChooGuard/Presentation/Overlays/ToolOverlayRouter.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.02.candidate`의 `A-CS-PLAY.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 각 reason에 원인·영향·관련 업무/보고·해결 조건·근거를 붙인다.

2. 전체 분석에서 기관 정보 보기로 전환해도 도메인 knowledge는 읽기만 한다.

3. 모달/도구 종료시 focus·selection·camera를 복원한다. 열린 창과 session pause는 다른 상태다.

```

### 정상·반례 시험

**TEST-CS-PLAY.04-P / NOT_RUN**

Given 권한과 정보가 모두 부족한 업무  
When 상세 열기  
Then 두 이유와 관련 연결을 모두 확인한다.

**TEST-CS-PLAY.04-N / NOT_RUN**

Given 비교 창을 닫음  
When 현재 run 검사  
Then 메시지·예약·업무가 사라지지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PLAY.05 · 접근성·재배정·텍스트와 반복 조작 효율

**산출물:** `A-CS-PLAY.05` — 큰 글자·키보드·한글·재사용 화면의 실제 runtime 수용

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Preferences는 물리·정보·업무 결과를 수정하지 않는다.

**관련 제품 요구:** REQ-072

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Accessibility/UiPreferences.cs`
- `Assets/ChooGuard/Presentation/Accessibility/FocusManager.cs`
- `Assets/ChooGuard/Presentation/Menu/WorkspaceLauncher.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play05Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.03.candidate`의 `A-CS-PLAY.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.04.candidate`의 `A-CS-PLAY.04` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 1920x1080 기준에서 창 크기·100/150/200% 텍스트·모달 포커스 순서를 검사한다.

2. World 정밀 클릭 없이 목록/업무 패널만으로 배정·취소·비교·근거 조회가 가능하게 한다.

3. 지원한 접근성 기능만 표시한다. DOM/웹 시험이나 Editor 성공을 Player 적합성으로 사용하지 않는다.

```

### 정상·반례 시험

**TEST-CS-PLAY.05-P / NOT_RUN**

Given 키보드와 큰 글자 설정  
When 일상 작성 과제 수행  
Then 필수 내용이 잘리지 않고 월드 클릭 없이 작업 가능하다.

**TEST-CS-PLAY.05-N / NOT_RUN**

Given 이미 modal이 열린 상태에서 키 shortcut  
When 입력  
Then 뒤 화면 명령이 실행되지 않으며 focus 복귀가 보존된다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

---

# CS-LAB — 저장된 운영안의 분기·비교 실험

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 동일 입력에서 운영 대안을 재현·수정·비교한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 완전 checkpoint·replay / 불변 분기와 복원가능성 / 공정한 반복 A/B / 변경영향·부분 재계산

**종료 조건:** 불완전 snapshot을 정확 분기로 표시하지 않음 / 내생 결과를 두 안에 강제 복사하지 않음 / 우열 불명·실패·미완료를 보존

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-LAB.01 | 이벤트 재생·완전 checkpoint | IMPLEMENTATION |

| CS-LAB.02 | 원본 불변 분기·재실행 | IMPLEMENTATION |

| CS-LAB.03 | 동일조건·불확도·비지배 비교 | IMPLEMENTATION |

| CS-LAB.04 | 변경 영향·캐시·부분 재실행 | IMPLEMENTATION |



## CS-LAB.01 · 이벤트 재생·완전 checkpoint

**산출물:** `A-CS-LAB.01` — 예약/메시지/난수/worker 상태를 담은 snapshot

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Checkpoint {runId,cutSeq,simTick,contentHashes,domain,random,workers,capabilities}; renderer state는 선택적.

**관련 제품 요구:** REQ-036

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/CheckpointService.cs`
- `Assets/ChooGuard/Experiments/ReplayReader.cs`
- `Assets/ChooGuard/Experiments/CheckpointManifest.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.02.candidate`의 `A-CS-OPS.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `qualification`. 조건: `EXTERNAL_WORKER_USED`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 공통 cut에서 업무·예약·기관지식·미전달 메시지·난수·worker 상태 또는 재계산 recipe를 모은다.

2. 필수 worker 목록은 capability와 run config에서 구한다. 파일 이름 존재만으로 정확 복원을 허용하지 않는다.

3. hash·version·시간을 검증한 후 manifest를 durable로 게시한다. 누락되면 복구 제한을 명시한다.

```

### 정상·반례 시험

**TEST-CS-LAB.01-P / NOT_RUN**

Given 전달중 메시지와 예약이 있는 run  
When snapshot·restore  
Then 의미상태와 미래 사건 순서가 지정 기준 내 일치한다.

**TEST-CS-LAB.01-N / NOT_RUN**

Given 필수 worker 내부 상태 누락  
When 정확 restore 요청  
Then 거부하고 검증된 checkpoint/처음부터 재계산 경로를 표시한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-LAB.02 · 원본 불변 분기·재실행

**산출물:** `A-CS-LAB.02` — parent-run/checkpoint가 연결된 새 실행

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** BranchReceipt {newRunId,parentRunId,checkpointHash,kind,changedPlan}; 리플레이는 새 실험이 아니다.

**관련 제품 요구:** REQ-037, REQ-057

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/BranchService.cs`
- `Assets/ChooGuard/Experiments/BranchLineage.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-LAB.01.candidate`의 `A-CS-LAB.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 runId와 parent checkpoint reference를 만들고 원래 run을 갱신하지 않는다.

2. 지원하는 정확 복원과 새 초기화 실행을 구별한다. user note는 과거 원래 의도로 덮어쓰지 않는다.

3. 불완전 복원 capability이면 특정 시점 branch를 비활성화하고 다른 시작점을 명시한다.

```

### 정상·반례 시험

**TEST-CS-LAB.02-P / NOT_RUN**

Given 완전 snapshot A  
When B 분기 후 배정 수정  
Then A 이벤트 hash가 불변이고 B 변경이 독립으로 남는다.

**TEST-CS-LAB.02-N / NOT_RUN**

Given checkpoint 파일 한 개 손상  
When branch 생성  
Then 정확분기 거부와 손상 파일 근거를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-LAB.03 · 동일조건·불확도·비지배 비교

**산출물:** `A-CS-LAB.03` — 의도적으로 고정한 외생조건과 조건별 비교 보고

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Comparison {basis,inputs,qoi,violations,uncertainty,status,selectionReason}; 현실 전체 최적을 주장하지 않음.

**관련 제품 요구:** REQ-038, REQ-039

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/ComparisonService.cs`
- `Assets/ChooGuard/Experiments/ExogenousScenarioStreams.cs`
- `Assets/ChooGuard/Experiments/ComparisonReport.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-LAB.02.candidate`의 `A-CS-LAB.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. map/rule/model/QoI basis가 호환되는지 먼저 검사한다. 외생 난수 혁신은 stable process key로 결속한다.

2. 사용자 조치가 바꾸는 후속 이동·보고·혼잡은 각 run에서 다시 계산한다.

3. 제약 위반을 속도 점수로 상쇄하지 않는다. 불확도·실패·우열 불명과 다목적 비지배 대안을 표시한다.

```

### 정상·반례 시험

**TEST-CS-LAB.03-P / NOT_RUN**

Given 같은 외부 조건과 다른 배정안  
When paired 비교  
Then 공통조건과 달라진 내생 결과가 구별된다.

**TEST-CS-LAB.03-N / NOT_RUN**

Given 다른 모델 버전 또는 평가범위  
When 전체 순위 계산  
Then 공통 가능 수량만 비교하거나 전체 비교 불가를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-LAB.04 · 변경 영향·캐시·부분 재실행

**산출물:** `A-CS-LAB.04` — 정확성 조건을 가진 빠른 반복 실험

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Impact {changedInputs,dirtyOutputs,evidence,allowedReuse,requiredRecompute}; 관계 부재는 영향 없음이 아님.

**관련 제품 요구:** REQ-084

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/ImpactGraph.cs`
- `Assets/ChooGuard/Experiments/ReplayCache.cs`
- `Assets/ChooGuard/Experiments/RunInvalidation.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-LAB.03.candidate`의 `A-CS-LAB.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 표현/서식 변경과 의미/물리 입력 변경을 구분한다.

2. 입력·버전·설정 hash와 영향 경계를 입증할 수 있을 때만 파생결과를 재사용한다.

3. 영향이 누락됐거나 비선형 파급을 제한할 수 없으면 확대 재계산한다. 과거 증거를 삭제하지 않고 현재 사용 자격을 STALE로 둔다.

```

### 정상·반례 시험

**TEST-CS-LAB.04-P / NOT_RUN**

Given 영향경계가 검증된 배정 변경  
When 부분과 전체 재계산 대조  
Then 동일 QoI/의미상태가 사전 허용범위 내다.

**TEST-CS-LAB.04-N / NOT_RUN**

Given 영향 그래프에 없는 물리 경계변경  
When 캐시 재사용  
Then 재사용을 거부하고 넓은 재계산을 요구한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

---

# CS-MODES — 매뉴얼 교육과 제약 기반 랜덤 실험

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 하나의 코어에 두 사용자 모드를 구성한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 실제 사례 기반 하나의 튜토리얼 과정 / 조건부 사건 생성 / 현장 묶음 재사용·다음 판단 지점 진행

**종료 조건:** TUTORIAL/RANDOM_OPERATIONS_LAB만 제공 / 힌트로 모델/자원 능력을 바꾸지 않음 / 추가지원 필요와 미지원 계산을 구별

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-MODES.01 | 한 개의 근거 기반 교육 과정 | IMPLEMENTATION |

| CS-MODES.02 | 제약 기반 랜덤 상황 | IMPLEMENTATION |

| CS-MODES.03 | 현장 재사용·모드 연결·다음 판단 지점 | IMPLEMENTATION |



## CS-MODES.01 · 한 개의 근거 기반 교육 과정

**산출물:** `A-CS-MODES.01` — 안내·힌트 축소·복기의 튜토리얼과 교육목표

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TutorialCourse {source,scope,goals,partialOrder,hints,assessment}; 공식 이수·훈련 정확재현은 별도 검수.

**관련 제품 요구:** REQ-003, REQ-004, REQ-065

### 만들 파일과 시험

- `Assets/ChooGuard/Scenarios/TutorialDirector.cs`
- `content/exercises/tutorial/course.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/MODES/Modes01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 실제 사례를 재구성한 부분과 원 대본이 확인된 부분을 구분한다.

2. 평가는 부분순서·조건·증거를 사용하고 독립 업무의 유효한 순서 변경을 허용한다.

3. 힌트는 표시만 바꾸며 물리·기관권한·자원능력·전달시간을 수정하지 않는다.

```

### 정상·반례 시험

**TEST-CS-MODES.01-P / NOT_RUN**

Given 같은 명령열과 조건  
When 힌트 ON/OFF 실행  
Then 의미상태가 같고 안내만 다르다.

**TEST-CS-MODES.01-N / NOT_RUN**

Given 서로 독립인 두 업무를 반대 순서로 수행  
When 교육 평가  
Then 필수 조건이 같으면 둘 다 허용한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [CASE-READY2026: 부강화물역 READY Korea 훈련](https://info.korail.com/info/selectBbsNttView.do?bbsNo=199&key=911&nttNo=26899)

- [CASE-YULHYEON: 2026 율현터널 KTX·SRT 비상대응훈련](https://info.korail.com/info/selectBbsNttView.do?bbsNo=199&key=911&nttNo=26342)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-MODES.02 · 제약 기반 랜덤 상황

**산출물:** `A-CS-MODES.02` — 인과·기관·공간·모델에 맞는 scenario generator

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** GeneratedScenario {spec,seedManifest,provenance,constraintReport,qualification}; 무작위 발생확률은 현실 빈도와 별개.

**관련 제품 요구:** REQ-005, REQ-006, REQ-007

### 만들 파일과 시험

- `Assets/ChooGuard/Scenarios/ScenarioGenerator.cs`
- `Assets/ChooGuard/Scenarios/ScenarioConstraintChecker.cs`
- `content/exercises/random/grammar.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/MODES/Modes02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 기관·공간·자원과 검토된 사건 문법을 입력으로 받고 조건부로 사건을 표본화한다.

2. 성공/거부 분포와 seed·각 난수 혁신·거부 이유를 보존한다. 반복상한에서 무한생성 대신 조건 조정을 요구한다.

3. FEASIBLE·ESCALATION_REQUIRED·CONFLICTED_INPUT·UNSUPPORTED_DOMAIN을 구분한다.

```

### 정상·반례 시험

**TEST-CS-MODES.02-P / NOT_RUN**

Given 동일 grammar·seed·content  
When 상황 생성  
Then 동일 재현조건과 사건·거부 이력이 남는다.

**TEST-CS-MODES.02-N / NOT_RUN**

Given 미지원 물리현상 또는 서로 모순된 자원  
When 생성  
Then 어려운 정상문제로 위장하지 않고 범위/입력 오류를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-MODES.03 · 현장 재사용·모드 연결·다음 판단 지점

**산출물:** `A-CS-MODES.03` — 재사용 workspace와 생략 없는 시간 진행

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Mode={TUTORIAL,RANDOM_OPERATIONS_LAB}; RuntimeConfig는 같은 코어와 lock을 공유.

**관련 제품 요구:** REQ-002, REQ-083, REQ-085

### 만들 파일과 시험

- `Assets/ChooGuard/Scenarios/WorkspaceSessionFactory.cs`
- `Assets/ChooGuard/Scenarios/DecisionBoundaryRunner.cs`
- `Assets/ChooGuard/Scenarios/ModePolicy.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/MODES/Modes03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-MODES.01.candidate`의 `A-CS-MODES.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-MODES.02.candidate`의 `A-CS-MODES.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.02.candidate`의 `A-CS-LAB.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.05.candidate`의 `A-CS-PLAY.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 현장·규칙·template·model 묶음을 읽고 새 운영안을 만든다. 원본 번들은 바꾸지 않는다.

2. 제품 모드는 두 개만 허용하고 analysis/branch/solver profile은 공통 도구로 둔다.

3. 다음 판단지점 이동은 사건과 solver를 순차 처리한다. 미래 결과를 예측 없이 미리 게시하거나 dt를 늘리지 않는다.

```

### 정상·반례 시험

**TEST-CS-MODES.03-P / NOT_RUN**

Given 중간 메시지·예약변화가 있는 긴 대기  
When 순차 진행과 다음 판단지점 진행 비교  
Then 동일 경계에서 의미상태·로그가 일치한다.

**TEST-CS-MODES.03-N / NOT_RUN**

Given required solver가 뒤처짐  
When 판단지점 건너뛰기  
Then 계산대기를 표시하고 미래 상태를 표시하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

---

# CS-SIM — 다중 물리·행동 계산과 정량 검증

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 운영 판단에 필요한 현상만 검증된 어댑터로 연결한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 격리 worker·기능협상 / 보행/층간 이동 / 접근교통/차량 / 화재/열/연기 기준계산 / 결합·불확도·선택적 가속

**종료 조건:** 수량별 단일 소유자·단위/시간/버전 일치 / 기준모델·최신 후보 공정 비교 / 유효범위 이탈·실패 시 결과를 정상처럼 표시하지 않음

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-SIM.01 | 새 worker 프로토콜·시험 워커 | IMPLEMENTATION |

| CS-SIM.02 | 보행·층간 연결 어댑터 | IMPLEMENTATION |

| CS-SIM.03 | 접근교통·차량 운행 어댑터 | IMPLEMENTATION |

| CS-SIM.04 | 화재·열·연기 기준 계산 | IMPLEMENTATION |

| CS-SIM.05 | 공동시간·불확도·가속·정직한 복구 | IMPLEMENTATION |



## CS-SIM.01 · 새 worker 프로토콜·시험 워커

**산출물:** `A-CS-SIM.01` — 능력협상·취소·재시도·구간결과와 명시적인 시험 워커

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** WorkerCapability, SimulationJob, FieldBatch; 임의 shell 문자열을 입력으로 실행하지 않는다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/WorkerTypes.cs`
- `Assets/ChooGuard/Simulation/WorkerProcessClient.cs`
- `workers/fixture/worker.py`
- `workers/protocol/worker.schema.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. length-framed JSON 또는 고정 JSONL 프로토콜을 선택해 크기 제한·protocol version·requestId를 검증한다. 로그와 프로토콜 출력 채널을 분리한다.

2. capability에 현상·단위·time-step·batch/interactive·checkpoint·검증영역을 선언한다.

3. worker timeout/exit/corrupt/late result/다른 branch 응답을 검사한다. 시험 워커는 SYNTHETIC_FIXTURE이며 실제 모델로 승격하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.01-P / NOT_RUN**

Given 유효한 job·시험 worker  
When 요청·결과 적용  
Then hash·run·boundary·시간 검사가 일치한 결과만 반환한다.

**TEST-CS-SIM.01-N / NOT_RUN**

Given 다른 run의 늦은 응답 또는 과대 payload  
When 수신  
Then 거부하고 현재 run을 변경하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SIM.02 · 보행·층간 연결 어댑터

**산출물:** `A-CS-SIM.02` — 현상별 비교 가능한 사람 이동과 보조 이동 계약

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** PedestrianState {entityId,frameId,position,velocity,tick,modelRef}; 독립 관측 전에는 현장 정확도 미판정.

**관련 제품 요구:** REQ-019, REQ-043

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/PedestrianAdapter.cs`
- `workers/pedestrian/runner.py`
- `benchmarks/pedestrian/protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.02.candidate`의 `A-CS-WORLD.02` → 이 작업 `qualification`. 조건: `NAMED_SITE_ACCURACY`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. JuPedSim 등의 기준·후보를 동일 geometry·독립 현상 데이터로 비교한다.

2. 위치의 정본은 한 엔진에만 둔다. Unity의 표시·회피 로직과 이중 소유하지 않는다.

3. 계단/승강기/보조 이동은 지원 범위를 별도 기술하고 기본 보행모델의 정확도를 자동 상속하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.02-P / NOT_RUN**

Given 검수된 병목 fixture와 기준 관측  
When 후보 실행  
Then 통과량·위치·대기분포·실패 범위를 기록한다.

**TEST-CS-SIM.02-N / NOT_RUN**

Given 미지원 층간 이동  
When 경로/수량 평가  
Then UNSUPPORTED와 적용 제외 범위를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-JPS14: JuPedSim v1.4.0 release announcement](https://github.com/PedestrianDynamics/jupedsim/discussions/1567)

- [TECH-JUPED: JuPedSim 보행 모델](https://www.jupedsim.org/stable/pedestrian_models/)

- [TECH-PEDDATA: Jülich Fair2Ped·보행 실험 아카이브](https://www.fz-juelich.de/en/ias/ias-7/research-1/projects/fair2ped-1)



## CS-SIM.03 · 접근교통·차량 운행 어댑터

**산출물:** `A-CS-SIM.03` — 지도밖 도착 가정과 정량 교통모델의 구분

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TrafficState {vehicleId,crewIds,routeId,frameId,tick,provenance}; 철도 운행은 충돌/탈선 동역학과 다름.

**관련 제품 요구:** REQ-044

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/TrafficAdapter.cs`
- `workers/traffic/runner.py`
- `benchmarks/traffic/protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. SUMO 등 후보에 현지 경로·가용성·차량·운행조건을 결속한다.

2. 정량 프로파일에서는 teleport·숨은 우회 등을 탐지하고 해당 실행의 자격을 제한한다.

3. 해당 QoI가 필요 없는 과제는 명시적 도착 시나리오 입력을 쓸 수 있지만 실제 출동시간 예측으로 부르지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.03-P / NOT_RUN**

Given 현지 조건과 이동 fixture  
When 접근시간 계산  
Then 입력·모델·shortcut 여부·오차 근거가 남는다.

**TEST-CS-SIM.03-N / NOT_RUN**

Given silent teleport 또는 없는 연결  
When 출동시간 출력  
Then 정상 예측 자격을 보류하고 근거를 남긴다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-SUMO: SUMO 긴급차량 모델](https://sumo.dlr.de/docs/Simulation/Emergency.html)

- [TECH-SUMO-RAIL: SUMO 철도 모델](https://sumo.dlr.de/docs/Simulation/Railways.html)



## CS-SIM.04 · 화재·열·연기 기준 계산

**산출물:** `A-CS-SIM.04` — 실제 geometry/material/boundary와 FDS 기준 결과

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** HazardRun {inputHash,solverLock,boundaryHistory,grid,qoi,resultRefs,validation}; 실제 관측없는 기준계산 일치는 현실 검증이 아님.

**관련 제품 요구:** REQ-042

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/HazardReferenceAdapter.cs`
- `workers/hazard/reference_runner.py`
- `benchmarks/hazard/reference-protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.02.candidate`의 `A-CS-WORLD.02` → 이 작업 `qualification`. 조건: `NAMED_SITE_ACCURACY`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 고정된 FDS 실행 버전과 물성·형상·개구·열원·경계·관측을 검사한다.

2. 기본 경로는 batch reference이며 live rollback을 지원한다고 가정하지 않는다. 수렴·독립 데이터·QoI를 별도 평가한다.

3. 필요 기준을 실행 전에 고정한다. 영상 전환·VFX를 온도/농도 데이터로 사용하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.04-P / NOT_RUN**

Given 검토된 기준실험과 input deck  
When solver 실행·대조  
Then 수치수렴·오차·적용범위·원시 결과를 납품한다.

**TEST-CS-SIM.04-N / NOT_RUN**

Given 물성이 없거나 폭발 충격파를 요청  
When 정량 평가  
Then 입력/현상 범위 불충족으로 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-FDS: FDS 매뉴얼·검증 안내](https://pages.nist.gov/fds-smv/manuals.html)

- [TECH-FDS-SCOPE: FDS 범위 및 FDS+Evac 지원 상태](https://pages.nist.gov/fds-smv/)



## CS-SIM.05 · 공동시간·불확도·가속·정직한 복구

**산출물:** `A-CS-SIM.05` — 선택한 worker들이 같은 경계에서 작동하는 결합과 model qualification

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** CommittedBoundary {tick,sequence,inputs,fieldOwners,resultHashes,capabilities}; 독립 reference/모델 결과는 runtime schema와 별도로 qualification.

**관련 제품 요구:** REQ-035, REQ-046, REQ-047, REQ-048, REQ-049

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/CosimulationCoordinator.cs`
- `Assets/ChooGuard/Simulation/QuantityOwnership.cs`
- `Assets/ChooGuard/Simulation/ModelQualification.cs`
- `workers/hazard/surrogate_runner.py`
- `benchmarks/coupling/protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim05Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.01.candidate`의 `A-CS-LAB.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SIM.02.candidate`의 `A-CS-SIM.02` → 이 작업 `qualification`. 조건: `PEDESTRIAN_QOI`.

- `CS-SIM.03.candidate`의 `A-CS-SIM.03` → 이 작업 `qualification`. 조건: `TRAFFIC_QOI`.

- `CS-SIM.04.candidate`의 `A-CS-SIM.04` → 이 작업 `qualification`. 조건: `HAZARD_QOI`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. run에서 사용하는 worker만 참여시켜 시간·단위·좌표·수량별 writer와 불연속 사건 동기화를 검사한다.

2. required worker 결과가 실패하면 경계를 commit하지 않는다. 복원이 안 되면 공통 유효 checkpoint/시작 상태부터 재계산한다.

3. 선택적 ROM/PhysicsNeMo 후보는 기준·관측·독립 형상에서 장기 roll-out·보존량·OOD를 검사한다. 가속모델이 없다는 이유로 필수 reference 경로를 삭제하지 않는다.

4. 훈련/비교에 쓰는 QoI가 요구하는 현상만 설치하되, 중요한 물리를 제외하고 정확도 주장을 유지하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.05-P / NOT_RUN**

Given 동일 문 이벤트가 이동·위험장에 영향  
When 공통 경계 적용  
Then 버전·tick·boundary가 일치하며 허용된 결합 오차를 보고한다.

**TEST-CS-SIM.05-N / NOT_RUN**

Given partial worker advance 후 장애 또는 OOD  
When 계산 지속 요청  
Then 묵시적 저정밀 대체 없이 대기/재계산/자격 보류를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [STD-FMI: FMI 3.0.2](https://fmi-standard.org/docs/3.0.2/)

- [TECH-MAPANYTHING: MapAnything: Universal Feed-Forward Metric 3D Reconstruction](https://github.com/facebookresearch/map-anything)

- [TECH-PHYSICSNEMO: NVIDIA PhysicsNeMo](https://docs.nvidia.com/physicsnemo/latest/index.html)

---

# CS-SCRIPT — 선택 운영안의 근거 기반 대본 저작

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 실행 사실과 규칙에서 검토 가능한 대본·실행데이터를 만든다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 근거 조회·권한 제한 AI / ScriptIR·조건부 운영규칙 / native 대본 편집·승인 만료 / 고객양식 출력·의미 변경 회수

**종료 조건:** LLM이 물리/권한/승인을 직접 변경하지 않음 / 대본과 실행형 시나리오 의미 일치 / 외부 서비스 실패에도 수동편집·저장 유지

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-SCRIPT.01 | 허용 근거 조회와 규칙/설명 후보 | IMPLEMENTATION |

| CS-SCRIPT.02 | 조건부 운영안·ScriptIR | IMPLEMENTATION |

| CS-SCRIPT.03 | native 대본 편집·검토 상태 | IMPLEMENTATION |

| CS-SCRIPT.04 | 고객 양식 출력·재로드·수정 회수 | IMPLEMENTATION |



## CS-SCRIPT.01 · 허용 근거 조회와 규칙/설명 후보

**산출물:** `A-CS-SCRIPT.01` — 권한제한 retrieval 및 근거가 결속된 AI 응답

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** AssistantProposal {type,claims,evidenceRefs,missing,patchDraft}; 결정적 상태 계산은 코어 담당.

**관련 제품 요구:** REQ-032, REQ-052, REQ-058, REQ-059

### 만들 파일과 시험

- `Assets/ChooGuard/Authoring/EvidenceQuery.cs`
- `Assets/ChooGuard/Authoring/AssistantGateway.cs`
- `workers/authoring/retrieve.py`
- `workers/authoring/contracts.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 기관·사건·판본·권한으로 문맥을 좁히고 실제 source locator를 연결한다.

2. AI는 규칙/설명/수정안 후보만 반환한다. 승인·DB쓰기·shell·운영명령 권한은 부여하지 않는다.

3. 문서/메모의 지시문을 데이터로 다루고 비용·timeout·반출 policy를 검사한다. 실패시 수동편집은 계속한다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.01-P / NOT_RUN**

Given 누락값이 있는 원문과 로그  
When 규칙 후보·설명 생성  
Then 미확인과 근거를 표시하고 숫자/기관을 창작하지 않는다.

**TEST-CS-SCRIPT.01-N / NOT_RUN**

Given 원문에 시스템지시처럼 보이는 문장  
When retrieval 처리  
Then 추가 권한이나 실행으로 해석하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SCRIPT.02 · 조건부 운영안·ScriptIR

**산출물:** `A-CS-SCRIPT.02` — 한 실행의 기록을 재사용 가능한 대응 운영규칙으로 저작

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ScriptIR {revision,plan,scenario,steps,roles,conditions,evidence,qualifications}; 내용변경은 새 revision.

**관련 제품 요구:** REQ-051, REQ-053, REQ-054

### 만들 파일과 시험

- `Assets/ChooGuard/Authoring/ScriptCompiler.cs`
- `Assets/ChooGuard/Authoring/ScriptIR.cs`
- `Assets/ChooGuard/Authoring/ScriptSemanticValidator.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SCRIPT.01.candidate`의 `A-CS-SCRIPT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.02.candidate`의 `A-CS-LAB.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 사실·사후 설명·가설·매뉴얼 근거 제안·검수된 지시를 단계별로 구분한다.

2. 실제 완료시각을 영구적인 정답 시각으로 바꾸지 않고 역할·선행조건·확인·예외로 표현한다.

3. 동일 ScriptIR에서 대본과 실행 데이터를 만들며 존재하지 않는 entity/rule/role을 거부한다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.02-P / NOT_RUN**

Given 선택된 운영안과 대표 실행  
When ScriptIR 생성  
Then 모든 사실은 event, 모든 규범제안은 rule/검수에 연결된다.

**TEST-CS-SCRIPT.02-N / NOT_RUN**

Given 기록 없는 업무를 수행했다고 기술  
When 의미 검사  
Then 근거누락을 반환하고 공식 대본으로 승격하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [REF-MSEL: FEMA Exercise Builder](https://preptoolkit.fema.gov/web/exercise)



## CS-SCRIPT.03 · native 대본 편집·검토 상태

**산출물:** `A-CS-SCRIPT.03` — TMP 편집·변경차이·의미검토·자격 표시

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ReviewDecision {reviewer,role,scope,revision,evidence,time,status}; focus와 UI가 승인권을 부여하지 않음.

**관련 제품 요구:** REQ-055, REQ-056

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Authoring/ScriptEditorPresenter.cs`
- `Assets/ChooGuard/Presentation/Authoring/ScriptEditor.prefab`
- `Assets/ChooGuard/Authoring/ReviewLedger.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SCRIPT.02.candidate`의 `A-CS-SCRIPT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.05.candidate`의 `A-CS-PLAY.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. native overlay에서 입력·선택·커서·IME를 유지하고 문장을 누르면 실제 근거를 연다.

2. 서식 변경과 의미 변경을 분리하고 의미 변경은 관련 검토를 만료시킨다.

3. 초안/시뮬레이션사용 검토/기관의 지정훈련 수용은 다른 주체·범위·버전 기록이다. 단어만으로 승인되지 않는다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.03-P / NOT_RUN**

Given 검토된 문서의 의미를 수정  
When 저장  
Then 원 로그 불변, 새 draft revision, 관련 승인 STALE.

**TEST-CS-SCRIPT.03-N / NOT_RUN**

Given AI 텍스트에 승인됨 문구 삽입  
When 표시/저장  
Then qualification 필드는 변경되지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SCRIPT.04 · 고객 양식 출력·재로드·수정 회수

**산출물:** `A-CS-SCRIPT.04` — 문서/실행데이터의 동일 의미와 출력 후 작업 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TemplateProfile {format,revision,fields,exporter,qualification}; 결과는 임의 script를 실행하지 않는다.

**관련 제품 요구:** REQ-086

### 만들 파일과 시험

- `Assets/ChooGuard/Authoring/ExportService.cs`
- `Assets/ChooGuard/Authoring/ImportReconciliation.cs`
- `workers/authoring/export_document.py`
- `content/templates/profiles.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SCRIPT.03.candidate`의 `A-CS-SCRIPT.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. JSON·Markdown·DOCX를 공통 IR에서 출력한다. 기관별 다른 형식은 실제 템플릿의 입력/출력 검증 후 활성화한다.

2. 출력 문서와 실행형 구조의 역할·사건·분기·조건을 비교한다.

3. 외부 편집본 의미diff는 수동 또는 지원한 importer로 조정한다. 자동 왕복이 안 되는 형식을 가능한 것으로 표시하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.04-P / NOT_RUN**

Given 같은 ScriptIR와 검증된 TemplateProfile  
When 문서 출력·실행형 재로드  
Then 의미가 일치하고 제한·근거·버전이 포함된다.

**TEST-CS-SCRIPT.04-N / NOT_RUN**

Given 미지원 템플릿 또는 누락된 승인근거  
When 승인본 출력  
Then 지원제한/초안으로 구분하고 실패·수작업을 기록한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `CUSTOMER_WORKFLOW_OR_TEMPLATE` / 요구범위 `CUSTOMER_EFFICACY_OR_FORMAT_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 모집/실제양식 확인 전 고객 효용/지원완료 주장 금지.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-05: HSEEP Design and Development](https://preptoolkit.fema.gov/web/hseep-resources/design-and-development)

- [DISC-07: Exercise Builder](https://preptoolkit.fema.gov/web/exercise)

---

# CS-PROOF — 사용자 가치·현장 적합성 검증

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 기술 성공과 실제 작성 효용·모델/기관 수용을 분리해 검증한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 실제 반복 작성팀 발견조사 / 종단 과제·장애·성능 / A/B/C·총인시/품질 / 현장/기관 지정 용도 검토

**종료 조건:** 문서 시험과 제품 시험 구분 / 소표본/미완료/도움/무인계산 정직하게 집계 / 독립 검수 없는 현실 승인 금지

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-PROOF.01 | 실제 작성팀·자료·시간 가설 조사 | USER_RESEARCH |

| CS-PROOF.02 | 종단 작동·장애·성능 검수 | IMPLEMENTATION |

| CS-PROOF.03 | A/B/C 사용자효용과 반복 비용 | USER_RESEARCH |

| CS-PROOF.04 | 지정 현장의 독립 검증·기관 수용 | FIELD_VALIDATION |



## CS-PROOF.01 · 실제 작성팀·자료·시간 가설 조사

**산출물:** `A-CS-PROOF.01` — 허용된 최근 과업과 파일럿 입력·검수자·총인시 관측

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** StudyIntake {consent,roles,caseRefs,workflow,template,measurements,missing}; 표본 제안과 모집 완료를 분리.

**관련 제품 요구:** REQ-077, REQ-078

### 만들 파일과 시험

- `research/discovery/protocol.md`
- `research/discovery/intake.schema.json`
- `research/discovery/time-observation.schema.json`

- 검사: `research/proof/01-evaluation-protocol.md`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

선행 제품 산출물 없음. 초기화를 실행하는 명령이나 과거 자료를 요구하지 않는다.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 반복 작성자·기관 협조자·검수자·자료담당을 구분하고 최근 대본/수정/양식을 허용범위에서 관찰한다.

2. 교육·대리입력·기관회신·무인계산·사람 작업량을 분리한다. 동일인 중첩시간은 합집합이다.

3. 자료/인터뷰 미확보는 해당 고객 실증만 제한한다. 합성 코어 구현을 막는 전역 선행이 아니다.

```

### 정상·반례 시험

**TEST-CS-PROOF.01-P / NOT_RUN**

Given 동의한 실제 최근 작성 과제  
When 업무 관찰  
Then 출처유형·누락·도움·수정과 가명화된 시간 원장이 남는다.

**TEST-CS-PROOF.01-N / NOT_RUN**

Given 인터뷰 없이 가상의 고객답변  
When 효용 분석  
Then 미조사로 유지하며 관측값으로 사용하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `CUSTOMER_WORKFLOW_OR_TEMPLATE` / 요구범위 `CUSTOMER_EFFICACY_OR_FORMAT_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 모집/실제양식 확인 전 고객 효용/지원완료 주장 금지.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-01: 상시훈련: 목적·주관기관·2024/2025 실시현황](https://www.mois.go.kr/frt/sub/a06/b11/disasterTraining_4/screen.do)

- [DISC-03: 수서평택고속선 KTX·SRT 연결 비상대응 훈련](https://info.korail.com/info/selectBbsNttView.do?bbsNo=199&key=911&nttNo=26342)

- [DISC-05: HSEEP Design and Development](https://preptoolkit.fema.gov/web/hseep-resources/design-and-development)

- [DISC-18: 재난관리체계](https://info.korail.com/info/contents.do?key=969)



## CS-PROOF.02 · 종단 작동·장애·성능 검수

**산출물:** `A-CS-PROOF.02` — 같은 실행을 UI·저장·시나리오·대본까지 시험하는 suite

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Qualification별 evidence bundle; 기능/성능/정량/현장 수용은 별도.

**관련 제품 요구:** REQ-001, REQ-070, REQ-074

### 만들 파일과 시험

- `Assets/ChooGuard/Tests/Acceptance/EndToEndFlowTests.cs`
- `Assets/ChooGuard/Tests/Acceptance/FaultInjectionTests.cs`
- `qualification/technical-profile.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PROOF/Proof02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.05.candidate`의 `A-CS-PLAY.05` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.04.candidate`의 `A-CS-LAB.04` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-MODES.03.candidate`의 `A-CS-MODES.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SCRIPT.04.candidate`의 `A-CS-SCRIPT.04` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. A안 문제발견→B수정→비교→대본→새 run을 실제 Player에서 끝까지 수행한다.

2. 저장실패·worker장애·로그손상·중복명령·UI뒤클릭·IME·network loss를 반례로 만든다.

3. 고정 부하에서 UI/렌더/운영/solver/AI 비용을 나누고 인원·모델을 몰래 낮추지 않는다.

```

### 정상·반례 시험

**TEST-CS-PROOF.02-P / NOT_RUN**

Given 완성된 첫 native 루프  
When 전체 과제와 재시작 실행  
Then 근거와 결과가 같은 run/revision에 연결되고 정상 복구된다.

**TEST-CS-PROOF.02-N / NOT_RUN**

Given 필수 원시 증거 없이 수동 완료표시  
When 수용 검사  
Then NOT_RUN/FAILED로 남으며 문서 검사를 대체 증거로 쓰지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PROOF.03 · A/B/C 사용자효용과 반복 비용

**산출물:** `A-CS-PROOF.03` — 순절감·정합성·3D 추가가치의 실제 평가

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** StudyResult {conditions,participants,quality,time,censoring,assistance,limits}; 제품정확도를 선호도로 증명하지 않음.

**관련 제품 요구:** REQ-069, REQ-079, REQ-080, REQ-081, REQ-082, REQ-089

### 만들 파일과 시험

- `research/usability/protocol.json`
- `research/usability/analysis.py`
- `research/usability/report-template.md`

- 검사: `research/proof/03-evaluation-protocol.md`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PROOF.01.candidate`의 `A-CS-PROOF.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.02.candidate`의 `A-CS-PROOF.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. A 고객기존방식, B 동일코어 표/타임라인, C UnityRTS 조건을 고정한다. B는 연구 조건이며 제품모드 추가가 아니다.

2. 순서·난이도·도움·기존AI 허용조건·검수가림을 기록하고 품질이 유지된 총인시를 비교한다.

3. 미완료·중단·보조·초기비용·유지비를 포함하며 20%는 사전합의한 탐색목표로만 쓴다.

```

### 정상·반례 시험

**TEST-CS-PROOF.03-P / NOT_RUN**

Given 실제 작성자와 동결된 과제  
When 조건별 수행  
Then 시간·품질·도움·중단과 해석 한계를 함께 보고한다.

**TEST-CS-PROOF.03-N / NOT_RUN**

Given 좋은 완료자만 남기거나 결과 후 기준 변경  
When 결론 산출  
Then INCONCLUSIVE/프로토콜 위반을 표시한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `CUSTOMER_WORKFLOW_OR_TEMPLATE` / 요구범위 `CUSTOMER_EFFICACY_OR_FORMAT_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 모집/실제양식 확인 전 고객 효용/지원완료 주장 금지.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-05: HSEEP Design and Development](https://preptoolkit.fema.gov/web/hseep-resources/design-and-development)

- [DISC-07: Exercise Builder](https://preptoolkit.fema.gov/web/exercise)

- [DISC-08: AI Assistance](https://www.conducttr.com/ai-assistance)

- [DISC-09: The XVR Platform](https://www.xvrsim.com/en/platform/)

- [DISC-11: Credibility Consideration for Digital Twins in Manufacturing](https://www.nist.gov/publications/credibility-consideration-digital-twins-manufacturing)

- [FREE-001: Free Low Poly Vehicles Pack](https://rgsdev.itch.io/free-low-poly-vehicles-pack)



## CS-PROOF.04 · 지정 현장의 독립 검증·기관 수용

**산출물:** `A-CS-PROOF.04` — 선택한 사용목적의 매뉴얼/기하/물리/결합과 새 관측 근거

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** UsePassport {site,scope,manuals,models,qoi,observations,uncertainty,reviews}; 실제 설비 제어 기능 없음.

**관련 제품 요구:** REQ-040, REQ-067, REQ-068, REQ-076, REQ-090

### 만들 파일과 시험

- `qualification/field/protocol.json`
- `qualification/field/passport.schema.json`
- `qualification/field/review-ledger.json`

- 검사: `research/proof/04-evaluation-protocol.md`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.04.candidate`의 `A-CS-PACK.04` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.02.candidate`의 `A-CS-PROOF.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SIM.05.candidate`의 `A-CS-SIM.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. QoI와 허용오차·독립 split을 사전 고정하고 대상별 규칙·형상·시간·행동·결합을 대조한다.

2. 실행가능·모델검증·현실 관측 연동·기관 지정훈련 수용을 분리한다. surrogate/reference 일치를 현장 검증으로 대체하지 않는다.

3. 안전한 도상/시범 검토와 별도 검수자를 기록한다. 추가 현상은 필요한 독립 증거가 준비될 때만 수용한다.

```

### 정상·반례 시험

**TEST-CS-PROOF.04-P / NOT_RUN**

Given 독립 관측·사용목적·기관 검수자  
When 해당 범위 검토  
Then 장소·시점·판본·모델·불확도·승인범위가 남는다.

**TEST-CS-PROOF.04-N / NOT_RUN**

Given 개발에 사용한 동일자료뿐 또는 실제 관측 없음  
When 디지털트윈/현장 정합 판정  
Then 범위별 미검증이며 전체 최고등급을 부여하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-11: Credibility Consideration for Digital Twins in Manufacturing](https://www.nist.gov/publications/credibility-consideration-digital-twins-manufacturing)

- [STD-DTC: Definition of a Digital Twin](https://www.digitaltwinconsortium.org/initiatives/the-definition-of-a-digital-twin/)

- [TECH-VV: NIST Verification and Validation Process of a Fire Model](https://www.nist.gov/publications/verification-and-validation-process-fire-model)

---

# CS-SHIP — 로컬 배포·복구·현장 확장

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 오프라인 사용과 갱신·복구·추가 현장을 반복 가능한 제품으로 인계한다.

**입력 문서:** [제품 기준](PRODUCT_BASELINE.md) · [신규 공통 계약](CONTRACTS.md)

**포함:** 실행파일·번들·모델 설치 / 백업·업그레이드·보관·외부전송 정책 / 새 구역/기관/유형 확장·비용

**종료 조건:** 깨끗한 PC에서 승인 범위 실행 / 복구 시 receipt/예약/실행 혈통 보존 / 새 현장의 기존 검증 자동 상속 금지

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-SHIP.01 | 오프라인 제품 묶음·업데이트 | IMPLEMENTATION |

| CS-SHIP.02 | 백업·스키마 갱신·장애 복구 | IMPLEMENTATION |

| CS-SHIP.03 | 새 현장·기관·사건 확장과 운영 인계 | IMPLEMENTATION |



## CS-SHIP.01 · 오프라인 제품 묶음·업데이트

**산출물:** `A-CS-SHIP.01` — PC 실행파일·native UI·필요 모델·번들·출력기 설치

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ProductManifest {buildLock,contentRefs,modelRefs,capabilities,qualification}; 구매승인은 개발선행이 아님.

**관련 제품 요구:** REQ-073, REQ-087

### 만들 파일과 시험

- `packaging/product-manifest.json`
- `scripts/release/Build-Installer.ps1`
- `packaging/update-policy.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SHIP/Ship01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.03.candidate`의 `A-CS-BOOT.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.02.candidate`의 `A-CS-PROOF.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.04.candidate`의 `A-CS-PROOF.04` → 이 작업 `qualification`. 조건: `CLAIM_FIELD_USE`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 source와 dependency lock·모델/콘텐츠 hash를 결속하고 개인정보·키·제한원본을 제외한다.

2. 원격AI·외부 worker는 승인된 환경에서만 사용하고 오프라인은 가용계산·저장·수동편집을 유지한다.

3. 기술 배포와 현장용 qualification을 구별하여 미검증 표식이 설치과정에서 사라지지 않게 한다.

```

### 정상·반례 시험

**TEST-CS-SHIP.01-P / NOT_RUN**

Given 깨끗한 PC와 네트워크 차단  
When 설치·실행·저장·편집  
Then 로컬 지원기능이 작동하고 미지원 부분을 표시한다.

**TEST-CS-SHIP.01-N / NOT_RUN**

Given 필수 번들 hash 불일치  
When 제품 시작  
Then 정합성 오류로 해당 실행을 막고 원인을 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SHIP.02 · 백업·스키마 갱신·장애 복구

**산출물:** `A-CS-SHIP.02` — 새 제품 내부에서의 안전한 저장형식 갱신과 restore

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** BackupManifest {cut,dbHash,blobHashes,schema,format,scope}; 삭제는 별도 명시된 운영정책에 따른다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Persistence/BackupService.cs`
- `Assets/ChooGuard/Persistence/SchemaUpgrade.cs`
- `packaging/restore-policy.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SHIP/Ship02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SHIP.01.candidate`의 `A-CS-SHIP.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.01.candidate`의 `A-CS-LAB.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. DB와 blob/checkpoint 참조를 일관된 cut으로 백업하고 누락·손상을 검사한다.

2. 이후 새 제품의 schema version 간 업그레이드는 별도 백업·검증·rollback 경로로 수행한다. 이는 초기화 이전 제품 호환을 뜻하지 않는다.

3. 복구후 receipt·예약·outbox·lineage를 검사한다. 해시는 동일성 검사용이며 기관 승인을 증명하는 서명이 아니다.

```

### 정상·반례 시험

**TEST-CS-SHIP.02-P / NOT_RUN**

Given 정상 백업과 지원하는 새 제품 버전  
When restore  
Then 같은 durable cut과 자원 보존을 확인한다.

**TEST-CS-SHIP.02-N / NOT_RUN**

Given 누락된 blob 또는 지원불가 schema  
When 업그레이드/복원  
Then 원본 보존·미지원 보고하며 자동 파괴하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SHIP.03 · 새 현장·기관·사건 확장과 운영 인계

**산출물:** `A-CS-SHIP.03` — 데이터 중심 확장과 책임·반복비용 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SiteRegistry+ReleaseScope; 물리·기관 수용은 그 범위의 별도 근거로 결속한다.

**관련 제품 요구:** REQ-075, REQ-088, REQ-091

### 만들 파일과 시험

- `content/releases/site-registry.json`
- `packaging/operations-handbook.md`
- `research/adoption/maintenance-ledger.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SHIP/Ship03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SHIP.02.candidate`의 `A-CS-SHIP.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-MODES.03.candidate`의 `A-CS-MODES.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.04.candidate`의 `A-CS-PROOF.04` → 이 작업 `qualification`. 조건: `CLAIM_FIELD_USE`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 지역/구역/기관 ID를 등록한다. 특정 과거 구역 수나 ID 대응을 강제하지 않는다.

2. 새 현장의 geometry·rules·model scope를 별도로 검토하고 기존 정확도를 자동 복사하지 않는다.

3. 설정/콘텐츠 변경과 코어코드 변경 비용, 유지보수 책임·관심/파일럿/구매를 구분해 남긴다.

```

### 정상·반례 시험

**TEST-CS-SHIP.03-P / NOT_RUN**

Given 새 현장 bundle과 독립 검수 범위  
When 확장 납품  
Then 코어 재작성 필요 여부와 해당 범위 자격·수동작업이 보인다.

**TEST-CS-SHIP.03-N / NOT_RUN**

Given 다른 역 bundle에 기존 현장 승인 재사용  
When 수용 요청  
Then 범위 불일치로 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-02: 2025년 상반기 안전한국훈련 실시](https://www.mois.go.kr/frt/bbs/type010/commonSelectBoardArticle.do?bbsId=BBSMSTR_000000000008&nttId=117612)

- [DISC-04: 메타버스에서 철도안전 미래 다져](https://www.srail.or.kr/cms/article/view.do?pageId=KR0502000000&postNo=1361)

- [DISC-07: Exercise Builder](https://preptoolkit.fema.gov/web/exercise)

- [DISC-08: AI Assistance](https://www.conducttr.com/ai-assistance)

- [DISC-09: The XVR Platform](https://www.xvrsim.com/en/platform/)

- [DISC-10: Virtual Reality Incident Command Training](https://www.dcc.edu/workforce-development/maritime/virtual-reality-training.aspx)
