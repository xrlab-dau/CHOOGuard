# 신규 구현 공통 계약

## 신규 프로젝트 구조
```text
Assets/ChooGuard/
  App/                 새 composition root, boot
  Contracts/           Unity 비의존 DTO·ports
  Domain/              기관·업무·자원·정보 규칙
  Application/         명령·조회·run orchestration
  Persistence/         SQLite·blob·outbox·backup
  Content/             bundle·규칙·자료 검증
  World/               좌표·anchor·로딩·도킹
  Presentation/        native uGUI/TMP·입력·카메라
  Experiments/         snapshot·branch·comparison
  Scenarios/           tutorial·조건부 random
  Simulation/          field ownership·worker bridge
  Authoring/           ScriptIR·검토·출력
  Art/                 새 입고 자산
  Scenes/              새 boot·fixture·첫 현장
  Tests/               EditMode·PlayMode·Acceptance
workers/               새 protocol과 격리 실행기
content/               새 site/rule/scenario/template
sources/               원문·원본 입고 manifest
research/              실제 사용자·시간·형성적 평가
benchmarks/            선택 현상별 독립 검증
qualification/         scope별 증거와 기관 검토
packaging/             설치·갱신·복구
scripts/               이 신규 프로젝트 전용 명령
```
이것은 만들 경로이지 이미 존재하는 새 저장소 파일 목록이 아니다. 기존 저장소에서 어떤 디렉터리도 복사할 필요가 없다.

## 모듈 참조
Contracts는 값·직렬화·공개 interface를 정의한다. Domain은 Contracts만 참조하고 Unity와 저장 provider를 참조하지 않는다. Application은 Domain과 Contracts를 사용하고 persistence/worker ports를 호출한다. Presentation/World는 read projection과 typed command를 사용한다. Persistence와 worker bridge는 정의된 port를 구현한다. App만 실제 구현을 조립한다.

형식·공개 계약은 CS-BOOT.02 및 CS-PACK.01에서 처음 만든다. 외부 solver/framework를 쓴다는 것이 같은 이름의 기존 프로젝트 API를 재사용한다는 뜻은 아니다.

## 주요 메시지의 의미
| 계약 | 반드시 포함할 정보 | 의미 |
|---|---|---|
| CommandIntent | intentId,runId,requesterId,actingAgencyId,actingTeamIds,actionId,targetIds,readSet,payload,createdAt | 실행 의도. 클릭 즉시 완료가 아님 |
| PreviewResult | runId,readSet,targetResults,reasons,proposedEffects | side effect 없음. 제출 시 다시 검사 |
| CommandReceipt | intentId,runId,fingerprint,sequence,commitId,status,targetResults,reasons | durable commit 뒤의 요청 수락/거부. Accepted가 task Completed가 아님 |
| SessionProjection | runId,revision,simTick,viewScope,entities,tasks,reasons | 한 기관 정보 또는 전체 분석의 읽기 모델 |
| CommitBatch | runId,expectedRevision,events,reservations,receipt,outbox,projection | 한 트랜잭션. fail이면 부분 publish 금지 |
| RuleClause | id,revision,scope,kind,guards,effects,handoffs,exceptions,source,review | 문헌 후보와 승인 규칙 분리 |
| OperationalPlan | id,revision,roles,tasks,conditions,resourcePolicies,informationFlows | 사용자가 수정하는 운영 규칙 |
| ScenarioSpec | id,revision,siteRef,initialState,externalProcessRules,seedManifest,modelScope | 외생 조건과 사건 문법. 내생결과 고정 금지 |
| WorkerCapability | protocol,modelRef,fields,units,frames,timeSupport,checkpointSupport,domain | 실제 지원 범위. 모든 solver에 rollback을 가정하지 않음 |
| SimulationJob | jobId,runId,modelRef,inputHashes,boundaryRevision,startTick,endTick,payloadRef | 각 시도와 의미 job은 구별 |
| FieldBatch | jobId,runId,fieldOwner,boundaryRevision,validTick,units,frames,resultHashes,status | stale/타branch/단위오류를 거부 |
| Checkpoint | parentRun,cutSequence,tick,domainSnapshot,randomStreams,workerStates,contentHashes,restoreMode | 모든 required 상태가 있어야 정확 분기 |
| Comparison | inputBasis,runRefs,violations,qoi,uncertainty,comparability,selectionReason | 모델범위내 결과 비교. 보편 최적 승인 아님 |
| ScriptIR | id,revision,scenarioRef,planRef,steps,roles,conditions,evidence,qualification | 문서·실행 데이터의 공통 의미 원본 |

필수 문자열·ID는 공백/잘못된 scope를 검사하고, 수치에 NaN/Infinity를 허용하지 않는다. 점유 수량·시간·단위의 범위를 스키마와 도메인에서 함께 검사한다. DTO를 읽은 후 호출자 변경이 실행에 영향을 주지 않도록 immutable value/copy 경계를 둔다.

## 저장·명령 불변식
한 run에는 writer가 하나다. 멱등 key는 run/requester/intent이며 같은 key의 payload가 다르면 충돌이다. DB 트랜잭션 안에서 readSet·현재 자원을 재검사하고 이벤트·예약·receipt·outbox를 함께 commit한다. 실패 시 메모리 candidate를 승인 상태로 게시하지 않는다. 외부 side effect는 outbox job/result 식별자로 중복 적용을 막는다.

논리 수량과 개인/승무원/차량 식별자 제약을 함께 검사한다. 업무 하나의 복합 예약은 all-or-nothing이고 독립 업무의 batch 부분 성공은 대상별 receipt로 나타낸다. 실패한 요청이 타 업무의 예약을 취소하지 않는다.

## 시간·snapshot 계약
wall clock, simulation tick, event sequence, observedAt, receivedAt, authoredAt은 별도다. 배속은 시간 경과 요청이며 수치 timestep을 임의로 늘릴 권한이 아니다. 원본 run은 불변이며 branching은 새 run과 parent reference를 생성한다.

worker가 상태 export를 지원하지 않으면 검증된 checkpoint/시작 상태에서 재계산한다. 해시가 같다고 물리적으로 정확한 모델이라고 판정하지 않는다. 카메라·텍스트·표시 LOD가 계산결과에 영향을 주지 않아야 한다.

## 공통 개발·검수 절차
- [ ] 배정된 새 작업 JSON과 이 계약을 읽고 입력·출력·정확한 새 수정경로를 확인한다.
- [ ] 작업의 정상·반례를 실제 테스트로 먼저 작성하고 의도한 실패를 확인한다.
- [ ] 계약을 충족하는 최소 구현을 만들고 단위·통합·필요한 Player 시험을 실행한다.
- [ ] 원시 결과·실제 명령·새 source hash·환경·실패와 미실행을 보존한다.
- [ ] 산출물의 구현/통합/정량/현장 자격을 구분해서 전달한다. 명세 문구를 실행결과로 복사하지 않는다.

새 버전의 실행 명령은 CS-BOOT.03에서 구현한다. 이 문서 묶음의 Python 명령은 문서 조회·검사만 수행한다. 아직 없는 Unity 빌드 스크립트를 실행했다고 기록하지 않는다.

## 개발 동시성
각 작업의 declared file은 한 writer가 편집한다. 새 프로젝트에서 공유 manifest/asmdef/scene의 편집자는 착수시에 정하고 개인을 미리 배정하지 않는다. upstream contract가 안정되면 test double로 unit 개발 가능하지만 integration은 실제 산출물이 필요하다. 에픽 전체 완료가 아니라 task artifact를 의존한다.

## 첫 기술 fixture
두 가상 기관, 두 공간, 문 하나, 두 팀, 차량/공유장비를 배정한다. A안에는 공유장비 경합과 보고 확인 대기를 둔다. B안에서 배정/보고 조건을 바꿔 같은 외생 입력으로 실행한다. 결과는 요청→예약→업무→보고의 차이를 표시하고 선택안에서 초안 JSON/문서를 생성한다. 모든 기관 명칭·소요시간은 기술시험용 합성값이며 실제 대응 절차가 아니다.
