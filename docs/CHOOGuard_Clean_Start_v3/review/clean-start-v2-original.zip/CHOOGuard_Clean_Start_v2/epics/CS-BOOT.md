# CS-BOOT — 새 Unity 제품의 부팅·입력·빌드 기반

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 빈 저장소에서 반복 가능한 native PC 실행본을 만든다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** Unity 프로젝트 신규 생성 / 패키지·렌더·스크립팅 backend 고정 / 도메인/표현 assembly 경계 / EditMode·PlayMode·Player 실행 경로

**종료 조건:** 새 checkout에서 프로젝트 열기·컴파일·부팅 재현 / 필수 패키지와 로컬 의존성 명시 / 과거 프로젝트·사설 로컬 경로 없이 실행

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-BOOT.01 | 새 프로젝트·의존성 잠금 | IMPLEMENTATION |

| CS-BOOT.02 | assembly 경계와 신규 공개 계약 | IMPLEMENTATION |

| CS-BOOT.03 | 새 테스트·빌드 실행 경로 | IMPLEMENTATION |



## CS-BOOT.01 · 새 프로젝트·의존성 잠금

**산출물:** `A-CS-BOOT.01` — 새 Unity 프로젝트, boot scene, 정확한 editor/package lock, 최초 실행 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** BuildBaseline {editorVersion, packageLockSha256, renderPipeline, backend, os, nativePlugins, buildReceiptRef}; 모든 값은 새 실행에서 기록.

**관련 제품 요구:** REQ-066

### 만들 파일과 시험

- `ProjectSettings/ProjectVersion.txt`
- `ProjectSettings/GraphicsSettings.asset`
- `Packages/manifest.json`
- `Packages/packages-lock.json`
- `Assets/ChooGuard/Scenes/Bootstrap.unity`
- `docs/build/baseline.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/BOOT/Boot01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

선행 제품 산출물 없음. 초기화를 실행하는 명령이나 과거 자료를 요구하지 않는다.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. Unity 6 LTS 계열의 URP 3D 프로젝트를 비어 있는 작업 폴더에 생성한다. 정확한 패치·OS·backend는 설치된 정식 조합으로 선택해 기록한다.

2. uGUI/TMP·Input System·Test Framework를 새로 확인/도입하고 전체 lock을 커밋한다. 한글 font asset은 공급경로만 기록하고 이 명세에 폰트 바이너리를 넣지 않는다.

3. Bootstrap에는 하나의 composition root와 EventSystem만 두고 default font·missing shader·입력 모듈 상태를 검사한다.

```

### 정상·반례 시험

**TEST-CS-BOOT.01-P / NOT_RUN**

Given 이전 프로젝트가 없는 작업 폴더  
When Unity에서 생성·열기·native PC build  
Then 패키지가 해결되고 부팅하며 정확 버전이 새 기록에 남는다.

**TEST-CS-BOOT.01-N / NOT_RUN**

Given 다른 PC 전용 DLL 경로 또는 해결되지 않은 패키지  
When 새 checkout에서 build  
Then 환경 오류로 실패를 보고하고 이전 실행본이나 성공 로그를 복사하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-BOOT.02 · assembly 경계와 신규 공개 계약

**산출물:** `A-CS-BOOT.02` — Contracts·Domain·Application·Presentation의 신규 참조 방향과 typed ports

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** IOperationsPort: Preview(intent), Submit(intent), ReadReceipt(runId,intentId), ReadProjection(view); 실제 완료는 후속 event.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/ChooGuard.Contracts.asmdef`
- `Assets/ChooGuard/Domain/ChooGuard.Domain.asmdef`
- `Assets/ChooGuard/Application/ChooGuard.Application.asmdef`
- `Assets/ChooGuard/Presentation/ChooGuard.Presentation.asmdef`
- `Assets/ChooGuard/Contracts/OperationsPorts.cs`
- `Assets/ChooGuard/App/CompositionRoot.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/BOOT/Boot02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.01.candidate`의 `A-CS-BOOT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. Contracts와 Domain은 UnityEngine에 의존하지 않는 경계로 만든다. 저장과 계산은 port로 연결한다.

2. CommandIntent, CommandReceipt, SessionProjection, IOperationsPort를 CONTRACTS.md의 신규 모델대로 정의한다.

3. CompositionRoot는 한 run당 한 state writer를 생성한다. 각 외부 worker는 별도 기능을 확인하기 전 생성하지 않는다.

```

### 정상·반례 시험

**TEST-CS-BOOT.02-P / NOT_RUN**

Given 새 assembly 집합  
When 참조 그래프와 compile 검사  
Then Domain에서 Unity API·UI 타입을 참조하지 않으며 boot에서 동일 계약의 test double을 연결한다.

**TEST-CS-BOOT.02-N / NOT_RUN**

Given Domain이 HUD 컴포넌트를 참조  
When assembly 검사  
Then 의존성 위반이 탐지되고 빌드 gate가 실패한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-BOOT.03 · 새 테스트·빌드 실행 경로

**산출물:** `A-CS-BOOT.03` — EditMode·PlayMode·Player 실행과 원시 결과 보존 명령

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TestReceipt {testSet, commit, environment, startedAt, command, resultFiles, status, notRunReason}; CI credential은 저장소에 넣지 않는다.

**관련 제품 요구:** REQ-061

### 만들 파일과 시험

- `scripts/Run-UnityTests.ps1`
- `scripts/Build-Player.ps1`
- `.github/workflows/verify.yml`
- `Assets/ChooGuard/Tests/EditMode/ChooGuard.EditModeTests.asmdef`
- `Assets/ChooGuard/Tests/PlayMode/ChooGuard.PlayModeTests.asmdef`

- 검사: `Assets/ChooGuard/Tests/EditMode/BOOT/Boot03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.01.candidate`의 `A-CS-BOOT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. UNITY_EDITOR_PATH와 PROJECT_PATH를 입력받아 Test Framework를 실행하고 결과 XML·로그·exit code를 보존한다.

2. 라이선스/장치가 없는 CI는 미실행으로 실패 또는 중립 상태를 명시하고 임의 PASS를 만들지 않는다.

3. 일반 compile smoke와 Player의 렌더·IME·입력·디스크 시험을 분리한다.

```

### 정상·반례 시험

**TEST-CS-BOOT.03-P / NOT_RUN**

Given 실행 가능한 Unity editor와 한 실패 시험  
When 테스트 스크립트 실행  
Then 실패 exit code와 NUnit XML이 전달된다.

**TEST-CS-BOOT.03-N / NOT_RUN**

Given editor 실행파일 부재  
When 같은 스크립트 실행  
Then NOT_RUN과 필요한 환경을 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.
