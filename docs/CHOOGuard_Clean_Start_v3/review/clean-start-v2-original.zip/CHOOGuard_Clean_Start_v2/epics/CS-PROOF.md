# CS-PROOF — 사용자 가치·현장 적합성 검증

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 기술 성공과 실제 작성 효용·모델/기관 수용을 분리해 검증한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 실제 반복 작성팀 발견조사 / 종단 과제·장애·성능 / A/B/C·총인시/품질 / 현장/기관 지정 용도 검토

**종료 조건:** 문서 시험과 제품 시험 구분 / 소표본/미완료/도움/무인계산 정직하게 집계 / 독립 검수 없는 현실 승인 금지

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-PROOF.01 | 실제 작성팀·자료·시간 가설 조사 | USER_RESEARCH |

| CS-PROOF.02 | 종단 작동·장애·성능 검수 | IMPLEMENTATION |

| CS-PROOF.03 | A/B/C 사용자효용과 반복 비용 | USER_RESEARCH |

| CS-PROOF.04 | 지정 현장의 독립 검증·기관 수용 | FIELD_VALIDATION |



## CS-PROOF.01 · 실제 작성팀·자료·시간 가설 조사

**산출물:** `A-CS-PROOF.01` — 허용된 최근 과업과 파일럿 입력·검수자·총인시 관측

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** StudyIntake {consent,roles,caseRefs,workflow,template,measurements,missing}; 표본 제안과 모집 완료를 분리.

**관련 제품 요구:** REQ-077, REQ-078

### 만들 파일과 시험

- `research/discovery/protocol.md`
- `research/discovery/intake.schema.json`
- `research/discovery/time-observation.schema.json`

- 검사: `research/proof/01-evaluation-protocol.md`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

선행 제품 산출물 없음. 초기화를 실행하는 명령이나 과거 자료를 요구하지 않는다.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 반복 작성자·기관 협조자·검수자·자료담당을 구분하고 최근 대본/수정/양식을 허용범위에서 관찰한다.

2. 교육·대리입력·기관회신·무인계산·사람 작업량을 분리한다. 동일인 중첩시간은 합집합이다.

3. 자료/인터뷰 미확보는 해당 고객 실증만 제한한다. 합성 코어 구현을 막는 전역 선행이 아니다.

```

### 정상·반례 시험

**TEST-CS-PROOF.01-P / NOT_RUN**

Given 동의한 실제 최근 작성 과제  
When 업무 관찰  
Then 출처유형·누락·도움·수정과 가명화된 시간 원장이 남는다.

**TEST-CS-PROOF.01-N / NOT_RUN**

Given 인터뷰 없이 가상의 고객답변  
When 효용 분석  
Then 미조사로 유지하며 관측값으로 사용하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `CUSTOMER_WORKFLOW_OR_TEMPLATE` / 요구범위 `CUSTOMER_EFFICACY_OR_FORMAT_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 모집/실제양식 확인 전 고객 효용/지원완료 주장 금지.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-01: 상시훈련: 목적·주관기관·2024/2025 실시현황](https://www.mois.go.kr/frt/sub/a06/b11/disasterTraining_4/screen.do)

- [DISC-03: 수서평택고속선 KTX·SRT 연결 비상대응 훈련](https://info.korail.com/info/selectBbsNttView.do?bbsNo=199&key=911&nttNo=26342)

- [DISC-05: HSEEP Design and Development](https://preptoolkit.fema.gov/web/hseep-resources/design-and-development)

- [DISC-18: 재난관리체계](https://info.korail.com/info/contents.do?key=969)



## CS-PROOF.02 · 종단 작동·장애·성능 검수

**산출물:** `A-CS-PROOF.02` — 같은 실행을 UI·저장·시나리오·대본까지 시험하는 suite

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Qualification별 evidence bundle; 기능/성능/정량/현장 수용은 별도.

**관련 제품 요구:** REQ-001, REQ-070, REQ-074

### 만들 파일과 시험

- `Assets/ChooGuard/Tests/Acceptance/EndToEndFlowTests.cs`
- `Assets/ChooGuard/Tests/Acceptance/FaultInjectionTests.cs`
- `qualification/technical-profile.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PROOF/Proof02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.05.candidate`의 `A-CS-PLAY.05` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.04.candidate`의 `A-CS-LAB.04` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-MODES.03.candidate`의 `A-CS-MODES.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SCRIPT.04.candidate`의 `A-CS-SCRIPT.04` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. A안 문제발견→B수정→비교→대본→새 run을 실제 Player에서 끝까지 수행한다.

2. 저장실패·worker장애·로그손상·중복명령·UI뒤클릭·IME·network loss를 반례로 만든다.

3. 고정 부하에서 UI/렌더/운영/solver/AI 비용을 나누고 인원·모델을 몰래 낮추지 않는다.

```

### 정상·반례 시험

**TEST-CS-PROOF.02-P / NOT_RUN**

Given 완성된 첫 native 루프  
When 전체 과제와 재시작 실행  
Then 근거와 결과가 같은 run/revision에 연결되고 정상 복구된다.

**TEST-CS-PROOF.02-N / NOT_RUN**

Given 필수 원시 증거 없이 수동 완료표시  
When 수용 검사  
Then NOT_RUN/FAILED로 남으며 문서 검사를 대체 증거로 쓰지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PROOF.03 · A/B/C 사용자효용과 반복 비용

**산출물:** `A-CS-PROOF.03` — 순절감·정합성·3D 추가가치의 실제 평가

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** StudyResult {conditions,participants,quality,time,censoring,assistance,limits}; 제품정확도를 선호도로 증명하지 않음.

**관련 제품 요구:** REQ-069, REQ-079, REQ-080, REQ-081, REQ-082, REQ-089

### 만들 파일과 시험

- `research/usability/protocol.json`
- `research/usability/analysis.py`
- `research/usability/report-template.md`

- 검사: `research/proof/03-evaluation-protocol.md`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PROOF.01.candidate`의 `A-CS-PROOF.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.02.candidate`의 `A-CS-PROOF.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. A 고객기존방식, B 동일코어 표/타임라인, C UnityRTS 조건을 고정한다. B는 연구 조건이며 제품모드 추가가 아니다.

2. 순서·난이도·도움·기존AI 허용조건·검수가림을 기록하고 품질이 유지된 총인시를 비교한다.

3. 미완료·중단·보조·초기비용·유지비를 포함하며 20%는 사전합의한 탐색목표로만 쓴다.

```

### 정상·반례 시험

**TEST-CS-PROOF.03-P / NOT_RUN**

Given 실제 작성자와 동결된 과제  
When 조건별 수행  
Then 시간·품질·도움·중단과 해석 한계를 함께 보고한다.

**TEST-CS-PROOF.03-N / NOT_RUN**

Given 좋은 완료자만 남기거나 결과 후 기준 변경  
When 결론 산출  
Then INCONCLUSIVE/프로토콜 위반을 표시한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `CUSTOMER_WORKFLOW_OR_TEMPLATE` / 요구범위 `CUSTOMER_EFFICACY_OR_FORMAT_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 모집/실제양식 확인 전 고객 효용/지원완료 주장 금지.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-05: HSEEP Design and Development](https://preptoolkit.fema.gov/web/hseep-resources/design-and-development)

- [DISC-07: Exercise Builder](https://preptoolkit.fema.gov/web/exercise)

- [DISC-08: AI Assistance](https://www.conducttr.com/ai-assistance)

- [DISC-09: The XVR Platform](https://www.xvrsim.com/en/platform/)

- [DISC-11: Credibility Consideration for Digital Twins in Manufacturing](https://www.nist.gov/publications/credibility-consideration-digital-twins-manufacturing)

- [FREE-001: Free Low Poly Vehicles Pack](https://rgsdev.itch.io/free-low-poly-vehicles-pack)



## CS-PROOF.04 · 지정 현장의 독립 검증·기관 수용

**산출물:** `A-CS-PROOF.04` — 선택한 사용목적의 매뉴얼/기하/물리/결합과 새 관측 근거

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** UsePassport {site,scope,manuals,models,qoi,observations,uncertainty,reviews}; 실제 설비 제어 기능 없음.

**관련 제품 요구:** REQ-040, REQ-067, REQ-068, REQ-076, REQ-090

### 만들 파일과 시험

- `qualification/field/protocol.json`
- `qualification/field/passport.schema.json`
- `qualification/field/review-ledger.json`

- 검사: `research/proof/04-evaluation-protocol.md`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.04.candidate`의 `A-CS-PACK.04` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.02.candidate`의 `A-CS-PROOF.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SIM.05.candidate`의 `A-CS-SIM.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. QoI와 허용오차·독립 split을 사전 고정하고 대상별 규칙·형상·시간·행동·결합을 대조한다.

2. 실행가능·모델검증·현실 관측 연동·기관 지정훈련 수용을 분리한다. surrogate/reference 일치를 현장 검증으로 대체하지 않는다.

3. 안전한 도상/시범 검토와 별도 검수자를 기록한다. 추가 현상은 필요한 독립 증거가 준비될 때만 수용한다.

```

### 정상·반례 시험

**TEST-CS-PROOF.04-P / NOT_RUN**

Given 독립 관측·사용목적·기관 검수자  
When 해당 범위 검토  
Then 장소·시점·판본·모델·불확도·승인범위가 남는다.

**TEST-CS-PROOF.04-N / NOT_RUN**

Given 개발에 사용한 동일자료뿐 또는 실제 관측 없음  
When 디지털트윈/현장 정합 판정  
Then 범위별 미검증이며 전체 최고등급을 부여하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-11: Credibility Consideration for Digital Twins in Manufacturing](https://www.nist.gov/publications/credibility-consideration-digital-twins-manufacturing)

- [STD-DTC: Definition of a Digital Twin](https://www.digitaltwinconsortium.org/initiatives/the-definition-of-a-digital-twin/)

- [TECH-VV: NIST Verification and Validation Process of a Fire Model](https://www.nist.gov/publications/verification-and-validation-process-fire-model)
