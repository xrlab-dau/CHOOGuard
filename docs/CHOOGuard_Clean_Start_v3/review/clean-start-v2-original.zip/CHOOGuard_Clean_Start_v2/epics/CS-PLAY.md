# CS-PLAY — Unity 네이티브 RTS 운영 작업공간

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 팀과 업무를 선택해 실제 명령을 제출하고 근거를 읽게 한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** uGUI·TMP·Input System 입력소유권 / RTS 선택/명령 미리보기 / HUD·카메라·월드마커 / 원인·정보·접근성·저작 오버레이

**종료 조건:** UI 뒤 월드 클릭·IME 단축키 충돌 없음 / 요청과 업무 완료를 구분 / 정밀 월드 클릭 없이 목록으로도 핵심 과업 가능

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-PLAY.01 | native 입력 소유권·IME | IMPLEMENTATION |

| CS-PLAY.02 | 팀·업무 선택과 명령 미리보기 | IMPLEMENTATION |

| CS-PLAY.03 | 게임 HUD·카메라·미니맵 | IMPLEMENTATION |

| CS-PLAY.04 | 복수 원인·기관별 정보·작업 오버레이 | IMPLEMENTATION |

| CS-PLAY.05 | 접근성·재배정·텍스트와 반복 조작 효율 | IMPLEMENTATION |



## CS-PLAY.01 · native 입력 소유권·IME

**산출물:** `A-CS-PLAY.01` — uGUI/TMP HUD와 월드/카메라 충돌 방지

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** InputOwner {context,pointerId,focus,modal}; 소비한 event를 하위 입력에 재전달하지 않는다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Input/InputContextRouter.cs`
- `Assets/ChooGuard/Presentation/Input/PointerCaptureOwner.cs`
- `Assets/ChooGuard/Presentation/Input/Operations.inputactions`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.01.candidate`의 `A-CS-BOOT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 모달→텍스트/IME→HUD→월드→카메라 순서로 입력 소유권을 고정한다.

2. pointer-down의 소유자를 up/cancel까지 유지하고 UI drag가 월드 선택으로 전환되지 않게 한다.

3. TMP 입력·IME 조합 중 Space/WASD/Esc를 game action으로 전달하지 않는다. 실제 Player에서 조합/확정/취소 시험을 한다.

```

### 정상·반례 시험

**TEST-CS-PLAY.01-P / NOT_RUN**

Given HUD 뒤에 선택 가능한 객체  
When HUD 클릭/드래그/휠  
Then UI만 반응하고 뒤 객체와 카메라는 반응하지 않는다.

**TEST-CS-PLAY.01-N / NOT_RUN**

Given 한글 입력 중 Space·Enter·Esc  
When native Player 입력  
Then 정지/재개/카메라 이벤트가 발생하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PLAY.02 · 팀·업무 선택과 명령 미리보기

**산출물:** `A-CS-PLAY.02` — RTS 선택·업무 우선 배정·혼합기관 결과 확인

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SelectionSet→CommandIntent→PreviewResult→CommandReceipt; UI 수락은 업무 완료가 아님.

**관련 제품 요구:** REQ-008, REQ-009, REQ-010

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Selection/SelectionService.cs`
- `Assets/ChooGuard/Presentation/Commands/CommandPreviewPresenter.cs`
- `Assets/ChooGuard/Presentation/Commands/CommandPreview.prefab`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.01.candidate`의 `A-CS-PLAY.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.01.candidate`의 `A-CS-OPS.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 팀·승무원 연결 차량을 기본 단위로 하고 목록/월드 선택을 같은 SelectionSet으로 연결한다.

2. 혼합기관 선택은 대상별 조건·요청/거부를 표시한다. 한 업무의 원자성 경계와 독립 업무의 부분 성공을 구분한다.

3. Submit은 명시적인 확인 뒤 수행한다. 테스트 double UI 완료와 실물 커널 통합 완료를 별도로 기록한다.

```

### 정상·반례 시험

**TEST-CS-PLAY.02-P / NOT_RUN**

Given 가용 팀과 이미 점유된 팀을 선택  
When 명령 미리보기  
Then 대상별 차이와 근거가 보이며 전체 성공처럼 표시하지 않는다.

**TEST-CS-PLAY.02-N / NOT_RUN**

Given 미리보기 뒤 자원 상태 변경  
When 제출  
Then 최신 receipt의 거부를 표시하고 UI 자체로 성공을 만들지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [GAME-EMERGENCY: EMERGENCY official](https://www.world-of-emergency.com/news/2023-09-15/234-the_new_emergency)

- [GAME-RESCUEHQ: Rescue HQ official store](https://store.playstation.com/en-us/concept/10002295)



## CS-PLAY.03 · 게임 HUD·카메라·미니맵

**산출물:** `A-CS-PLAY.03` — WorldCamera 위에 native 운영 HUD와 선택 마커

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** UIState {selection,camera,openPanels,textScale}; 운영 상태와 수명을 분리.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Hud/OperationsHud.prefab`
- `Assets/ChooGuard/Presentation/Hud/HudPresenter.cs`
- `Assets/ChooGuard/Presentation/Camera/OperationsCamera.cs`
- `Assets/ChooGuard/Presentation/Hud/MinimapPresenter.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.01.candidate`의 `A-CS-PLAY.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.03.candidate`의 `A-CS-WORLD.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. WorldCamera를 중앙으로 하고 접이식 조직 목록·inspector·command dock·timeline을 overlay canvas로 조립한다.

2. 미니맵은 실제 위치를 투영하거나 별도 camera를 사용한다. 클릭 변환은 실제 pixelRect·층·DPI를 반영한다.

3. 위치 변경 애니메이션은 receipt/물리 결과를 따라가며 업무 완료나 실제 도착의 근거가 되지 않는다.

```

### 정상·반례 시험

**TEST-CS-PLAY.03-P / NOT_RUN**

Given 실제 fixture scene과 entity projection  
When 카메라 이동·선택·minimap 조작  
Then 같은 entity와 frame으로 표시·초점이 연결된다.

**TEST-CS-PLAY.03-N / NOT_RUN**

Given 화면 비율 변경 또는 다른 층  
When 미니맵 클릭  
Then 잘못된 층/좌표로 명령을 보내지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PLAY.04 · 복수 원인·기관별 정보·작업 오버레이

**산출물:** `A-CS-PLAY.04` — 대기 사유·근거·타임라인·비교/대본 화면의 native 연결

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ReasonView/AgencyTimeline는 read-only; pause는 코어 ack 이후 표시.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Inspector/ReasonInspector.cs`
- `Assets/ChooGuard/Presentation/Timeline/AgencyTimeline.cs`
- `Assets/ChooGuard/Presentation/Overlays/ToolOverlayRouter.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.02.candidate`의 `A-CS-PLAY.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 각 reason에 원인·영향·관련 업무/보고·해결 조건·근거를 붙인다.

2. 전체 분석에서 기관 정보 보기로 전환해도 도메인 knowledge는 읽기만 한다.

3. 모달/도구 종료시 focus·selection·camera를 복원한다. 열린 창과 session pause는 다른 상태다.

```

### 정상·반례 시험

**TEST-CS-PLAY.04-P / NOT_RUN**

Given 권한과 정보가 모두 부족한 업무  
When 상세 열기  
Then 두 이유와 관련 연결을 모두 확인한다.

**TEST-CS-PLAY.04-N / NOT_RUN**

Given 비교 창을 닫음  
When 현재 run 검사  
Then 메시지·예약·업무가 사라지지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-PLAY.05 · 접근성·재배정·텍스트와 반복 조작 효율

**산출물:** `A-CS-PLAY.05` — 큰 글자·키보드·한글·재사용 화면의 실제 runtime 수용

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Preferences는 물리·정보·업무 결과를 수정하지 않는다.

**관련 제품 요구:** REQ-072

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Accessibility/UiPreferences.cs`
- `Assets/ChooGuard/Presentation/Accessibility/FocusManager.cs`
- `Assets/ChooGuard/Presentation/Menu/WorkspaceLauncher.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PLAY/Play05Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PLAY.03.candidate`의 `A-CS-PLAY.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.04.candidate`의 `A-CS-PLAY.04` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 1920x1080 기준에서 창 크기·100/150/200% 텍스트·모달 포커스 순서를 검사한다.

2. World 정밀 클릭 없이 목록/업무 패널만으로 배정·취소·비교·근거 조회가 가능하게 한다.

3. 지원한 접근성 기능만 표시한다. DOM/웹 시험이나 Editor 성공을 Player 적합성으로 사용하지 않는다.

```

### 정상·반례 시험

**TEST-CS-PLAY.05-P / NOT_RUN**

Given 키보드와 큰 글자 설정  
When 일상 작성 과제 수행  
Then 필수 내용이 잘리지 않고 월드 클릭 없이 작업 가능하다.

**TEST-CS-PLAY.05-N / NOT_RUN**

Given 이미 modal이 열린 상태에서 키 shortcut  
When 입력  
Then 뒤 화면 명령이 실행되지 않으며 focus 복귀가 보존된다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.
