# CS-OPS — 영속 상태를 가진 다기관 운영 커널

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 요청·권한·자원·업무·보고의 실제 상태변화를 한 권위자로 실행한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 명령 계약·단일 writer / SQLite·원자 예약·outbox / 기관 권한/지원요청 / 업무망·지식·다축 원인

**종료 조건:** 저장 전 성공 응답 없음 / 중복 예약과 요청 재적용 없음 / 기관 수신 정보와 작성자 전체 분석 분리

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-OPS.01 | 신규 run·단일 writer·명령 상태머신 | IMPLEMENTATION |

| CS-OPS.02 | SQLite 저장·원자 예약·outbox | IMPLEMENTATION |

| CS-OPS.03 | 기관 권한·지원요청·인계 | IMPLEMENTATION |

| CS-OPS.04 | 기관별 정보·보고·인계 상태 | IMPLEMENTATION |

| CS-OPS.05 | 업무 의존·공간 접근·예약 생명주기 | IMPLEMENTATION |

| CS-OPS.06 | 다축 원인·교착·형식 모델 대조 | IMPLEMENTATION |



## CS-OPS.01 · 신규 run·단일 writer·명령 상태머신

**산출물:** `A-CS-OPS.01` — fresh OperationsSession과 미리보기/접수/조회 포트

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** CommandIntent→CommandReceipt, stateVersion/readSet; 수락은 수행완료와 다르다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Application/OperationsSession.cs`
- `Assets/ChooGuard/Application/CommandDispatcher.cs`
- `Assets/ChooGuard/Domain/RunState.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. run별 mailbox와 single-writer queue를 만들고 순서는 simulation tick·priority·monotonic sequence로 고정한다.

2. Preview는 side effect 없이 현재 guard를 평가한다. Submit은 requester와 acting team을 구분해 재검사한다.

3. 같은 key+payload는 같은 receipt, 다른 payload는 INTENT_CONFLICT를 반환한다. 인메모리 double은 기능시험 전용이다.

```

### 정상·반례 시험

**TEST-CS-OPS.01-P / NOT_RUN**

Given 같은 intentId·payload 두 번  
When 명령 제출  
Then 논리 변경 1회와 동일 receipt를 돌려준다.

**TEST-CS-OPS.01-N / NOT_RUN**

Given preview 이후 대상 revision 변경  
When submit  
Then STALE_READSET이며 업무 상태를 바꾸지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-OPS.02 · SQLite 저장·원자 예약·outbox

**산출물:** `A-CS-OPS.02` — 영속 commit과 자원 예약을 동일 경계에서 처리하는 기반

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** IRunStore.Commit(CommitBatch)→CommitReceipt; CommitBatch includes expectedRevision,events,reservations,receipt,outbox; 원본 append-only.

**관련 제품 요구:** REQ-024, REQ-071

### 만들 파일과 시험

- `Assets/ChooGuard/Persistence/SqliteRunStore.cs`
- `Assets/ChooGuard/Persistence/SqliteProvider.cs`
- `Assets/ChooGuard/Persistence/Schema.sql`
- `Assets/ChooGuard/Domain/ReservationPlanner.cs`
- `Assets/ChooGuard/Application/OutboxDispatcher.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.01.candidate`의 `A-CS-OPS.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 대상 Unity Player의 managed/native SQLite 조합을 smoke-test하고 pin한다. 플랫폼별 P/Invoke 성공을 확인한다.

2. BEGIN IMMEDIATE 경계에서 run revision·현재 자원 가용량을 재검사한다. 팀 구성원·승무원은 고유 ID로 중복점유를 검사한다.

3. 이벤트·예약·receipt·projection revision·outbox를 원자적으로 저장하고 commit 성공 뒤에만 acceptance를 게시한다.

4. 외부 전달은 재시도 가능하지만 jobId/resultId로 멱등 적용한다. 디스크 실패 후 candidate 메모리 상태를 게시하지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.02-P / NOT_RUN**

Given 팀·차량·장비를 모두 요구하고 모두 가용  
When 배정 commit  
Then 모든 예약과 receipt가 함께 기록되고 재시작 후 복원된다.

**TEST-CS-OPS.02-N / NOT_RUN**

Given 장비 하나 부족 또는 commit 직전 저장 실패  
When 복합 배정  
Then 새 예약은 0개, 기존 예약은 유지, 성공 응답은 없음.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-TAPAAL: TAPAAL](https://www.tapaal.net/features/)



## CS-OPS.03 · 기관 권한·지원요청·인계

**산출물:** `A-CS-OPS.03` — 명령 scope와 기관 간 협조를 분리한 권한 정책

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** AuthorityGrant {holder,agency,scope,revision,ruleRef}; RequestSupport와 AssignTask는 구별.

**관련 제품 요구:** REQ-021, REQ-022

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/AuthorityPolicy.cs`
- `Assets/ChooGuard/Domain/SupportRequest.cs`
- `Assets/ChooGuard/Domain/HandoverPolicy.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.02.candidate`의 `A-CS-OPS.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 작성자의 가상 설계권과 기관의 업무권을 구분한다.

2. 기관내 지시와 기관간 요청은 서로 다른 event로 처리한다.

3. 인계에는 원 권한 revision·범위·상대 확인·사유를 요구하며 후착 도착 자체는 전역 권한을 바꾸지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.03-P / NOT_RUN**

Given 유효한 scope의 인계가 완료됨  
When 새 담당자의 범위내 지시  
Then 해당 범위에만 권한 변경이 적용된다.

**TEST-CS-OPS.03-N / NOT_RUN**

Given 타기관 유닛에 직접 명령 또는 오래된 인계 revision  
When 지시 제출  
Then 권한거부/충돌과 적용 규칙 근거를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-KORAIL: 코레일 재난관리체계](https://info.korail.com/info/contents.do?key=969)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-OPS.04 · 기관별 정보·보고·인계 상태

**산출물:** `A-CS-OPS.04` — 보고의 생성/송신/수신/확인/적용과 지식 projection

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Message {id,sender,recipient,observedTick,receivedTick,expiry,payloadRef,ack}; projection은 read-only.

**관련 제품 요구:** REQ-011, REQ-027, REQ-028

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/MessageLifecycle.cs`
- `Assets/ChooGuard/Domain/KnowledgeState.cs`
- `Assets/ChooGuard/Application/AgencyProjection.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.03.candidate`의 `A-CS-OPS.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. messageId·관측시각·전달상태·TTL·수신기관을 기록한다.

2. 중복은 같은 의미효과를 재적용하지 않고 역순·상충 보고는 UNKNOWN/CONFLICTED 상태로 남긴다.

3. 작성자 전체 분석 projection이 기관 knowledge를 수정하지 못하게 한다. 미래 상태를 과거 복기의 지식으로 사용하지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.04-P / NOT_RUN**

Given 발송했지만 수신 전인 보고  
When 기관별 조회  
Then 발신자는 송신 상태, 수신자는 미수신 상태를 본다.

**TEST-CS-OPS.04-N / NOT_RUN**

Given 최신 보고 뒤 도착한 오래된 보고  
When 처리  
Then 최신값을 덮지 않고 과거/상충 근거로 보존한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-OPS.05 · 업무 의존·공간 접근·예약 생명주기

**산출물:** `A-CS-OPS.05` — 시간·자원·능력·정보 조건에 반응하는 운영 workflow

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TaskState {lifecycle,guards,reasons,reservations,outcome,handoff}; GuardResult는 truth/status와 evidence refs를 가진다.

**관련 제품 요구:** REQ-012, REQ-023, REQ-025, REQ-026, REQ-029, REQ-045

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/WorkflowEngine.cs`
- `Assets/ChooGuard/Domain/ResourceLifecycle.cs`
- `Assets/ChooGuard/Domain/TaskConditions.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops05Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.04.candidate`의 `A-CS-OPS.04` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 요청→배정→준비/이동→수행→보고/인계→반환 중 업무별 필요한 단계를 명시한다.

2. 작업 소요시간은 근거가 있는 조건부 입력으로 받는다. 합성 값은 검증된 현장 예측과 분리한다.

3. 팀 분리/결합·취소·교대·재보급은 능력과 자원 점유를 다시 검사한다. 수용·의료 인계는 운영상태이며 임상 판단을 생성하지 않는다.

```

### 정상·반례 시험

**TEST-CS-OPS.05-P / NOT_RUN**

Given 선행 업무와 수신확인·자원·접근 조건이 모두 충족  
When 업무 시작 평가  
Then 한 번만 시작하며 완료/보고/재가용을 별개로 기록한다.

**TEST-CS-OPS.05-N / NOT_RUN**

Given 업무 완료됐으나 회복/재보급 조건 미충족  
When 즉시 재배정  
Then 대기 이유와 가용 조건을 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-MEDICAL: 재난응급의료 비상대응매뉴얼 개정·배포](https://www.mohw.go.kr/board.es?act=view&bid=0009&list_no=1478957&mid=a10402000000&nPage=1&tag=)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-OPS.06 · 다축 원인·교착·형식 모델 대조

**산출물:** `A-CS-OPS.06` — 권한/정보/자원/이동/안전/evidence의 원인과 wait-for 분석

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Reason {axis,code,subject,causes,evidence,resolutionConditions}; 설명 모델은 권한·결과를 변경하지 못함.

**관련 제품 요구:** REQ-013, REQ-030, REQ-041

### 만들 파일과 시험

- `Assets/ChooGuard/Domain/ReasonEngine.cs`
- `Assets/ChooGuard/Domain/WaitForAnalyzer.cs`
- `benchmarks/operations/model-projection.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/OPS/Ops06Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 진행상태와 원인축을 별개로 출력하며 다수 원인을 보존한다.

2. wait-for graph에서 cycle을 탐지하되 외부 도착 예정/불충분 정보와 확정 교착을 구별한다.

3. TAPAAL에 투영 가능한 부분의 trace를 비교하고 timeout·범위 제한은 미검증으로 보고한다.

```

### 정상·반례 시험

**TEST-CS-OPS.06-P / NOT_RUN**

Given A가 B의 자원, B가 A의 보고를 기다림  
When 원인 분석  
Then 연결된 업무·요청·자원과 검토 가능한 cycle을 보여준다.

**TEST-CS-OPS.06-N / NOT_RUN**

Given 외부 도착이 예정된 정상 대기  
When 동일 분석  
Then 확정 교착으로 자동 판정하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-TAPAAL: TAPAAL](https://www.tapaal.net/features/)
