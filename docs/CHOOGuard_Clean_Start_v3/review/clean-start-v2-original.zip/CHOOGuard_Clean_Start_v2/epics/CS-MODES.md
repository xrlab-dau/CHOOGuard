# CS-MODES — 매뉴얼 교육과 제약 기반 랜덤 실험

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 하나의 코어에 두 사용자 모드를 구성한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 실제 사례 기반 하나의 튜토리얼 과정 / 조건부 사건 생성 / 현장 묶음 재사용·다음 판단 지점 진행

**종료 조건:** TUTORIAL/RANDOM_OPERATIONS_LAB만 제공 / 힌트로 모델/자원 능력을 바꾸지 않음 / 추가지원 필요와 미지원 계산을 구별

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-MODES.01 | 한 개의 근거 기반 교육 과정 | IMPLEMENTATION |

| CS-MODES.02 | 제약 기반 랜덤 상황 | IMPLEMENTATION |

| CS-MODES.03 | 현장 재사용·모드 연결·다음 판단 지점 | IMPLEMENTATION |



## CS-MODES.01 · 한 개의 근거 기반 교육 과정

**산출물:** `A-CS-MODES.01` — 안내·힌트 축소·복기의 튜토리얼과 교육목표

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TutorialCourse {source,scope,goals,partialOrder,hints,assessment}; 공식 이수·훈련 정확재현은 별도 검수.

**관련 제품 요구:** REQ-003, REQ-004, REQ-065

### 만들 파일과 시험

- `Assets/ChooGuard/Scenarios/TutorialDirector.cs`
- `content/exercises/tutorial/course.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/MODES/Modes01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 실제 사례를 재구성한 부분과 원 대본이 확인된 부분을 구분한다.

2. 평가는 부분순서·조건·증거를 사용하고 독립 업무의 유효한 순서 변경을 허용한다.

3. 힌트는 표시만 바꾸며 물리·기관권한·자원능력·전달시간을 수정하지 않는다.

```

### 정상·반례 시험

**TEST-CS-MODES.01-P / NOT_RUN**

Given 같은 명령열과 조건  
When 힌트 ON/OFF 실행  
Then 의미상태가 같고 안내만 다르다.

**TEST-CS-MODES.01-N / NOT_RUN**

Given 서로 독립인 두 업무를 반대 순서로 수행  
When 교육 평가  
Then 필수 조건이 같으면 둘 다 허용한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [CASE-READY2026: 부강화물역 READY Korea 훈련](https://info.korail.com/info/selectBbsNttView.do?bbsNo=199&key=911&nttNo=26899)

- [CASE-YULHYEON: 2026 율현터널 KTX·SRT 비상대응훈련](https://info.korail.com/info/selectBbsNttView.do?bbsNo=199&key=911&nttNo=26342)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-MODES.02 · 제약 기반 랜덤 상황

**산출물:** `A-CS-MODES.02` — 인과·기관·공간·모델에 맞는 scenario generator

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** GeneratedScenario {spec,seedManifest,provenance,constraintReport,qualification}; 무작위 발생확률은 현실 빈도와 별개.

**관련 제품 요구:** REQ-005, REQ-006, REQ-007

### 만들 파일과 시험

- `Assets/ChooGuard/Scenarios/ScenarioGenerator.cs`
- `Assets/ChooGuard/Scenarios/ScenarioConstraintChecker.cs`
- `content/exercises/random/grammar.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/MODES/Modes02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 기관·공간·자원과 검토된 사건 문법을 입력으로 받고 조건부로 사건을 표본화한다.

2. 성공/거부 분포와 seed·각 난수 혁신·거부 이유를 보존한다. 반복상한에서 무한생성 대신 조건 조정을 요구한다.

3. FEASIBLE·ESCALATION_REQUIRED·CONFLICTED_INPUT·UNSUPPORTED_DOMAIN을 구분한다.

```

### 정상·반례 시험

**TEST-CS-MODES.02-P / NOT_RUN**

Given 동일 grammar·seed·content  
When 상황 생성  
Then 동일 재현조건과 사건·거부 이력이 남는다.

**TEST-CS-MODES.02-N / NOT_RUN**

Given 미지원 물리현상 또는 서로 모순된 자원  
When 생성  
Then 어려운 정상문제로 위장하지 않고 범위/입력 오류를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-MODES.03 · 현장 재사용·모드 연결·다음 판단 지점

**산출물:** `A-CS-MODES.03` — 재사용 workspace와 생략 없는 시간 진행

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Mode={TUTORIAL,RANDOM_OPERATIONS_LAB}; RuntimeConfig는 같은 코어와 lock을 공유.

**관련 제품 요구:** REQ-002, REQ-083, REQ-085

### 만들 파일과 시험

- `Assets/ChooGuard/Scenarios/WorkspaceSessionFactory.cs`
- `Assets/ChooGuard/Scenarios/DecisionBoundaryRunner.cs`
- `Assets/ChooGuard/Scenarios/ModePolicy.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/MODES/Modes03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-MODES.01.candidate`의 `A-CS-MODES.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-MODES.02.candidate`의 `A-CS-MODES.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.02.candidate`의 `A-CS-LAB.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.05.candidate`의 `A-CS-PLAY.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 현장·규칙·template·model 묶음을 읽고 새 운영안을 만든다. 원본 번들은 바꾸지 않는다.

2. 제품 모드는 두 개만 허용하고 analysis/branch/solver profile은 공통 도구로 둔다.

3. 다음 판단지점 이동은 사건과 solver를 순차 처리한다. 미래 결과를 예측 없이 미리 게시하거나 dt를 늘리지 않는다.

```

### 정상·반례 시험

**TEST-CS-MODES.03-P / NOT_RUN**

Given 중간 메시지·예약변화가 있는 긴 대기  
When 순차 진행과 다음 판단지점 진행 비교  
Then 동일 경계에서 의미상태·로그가 일치한다.

**TEST-CS-MODES.03-N / NOT_RUN**

Given required solver가 뒤처짐  
When 판단지점 건너뛰기  
Then 계산대기를 표시하고 미래 상태를 표시하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.
