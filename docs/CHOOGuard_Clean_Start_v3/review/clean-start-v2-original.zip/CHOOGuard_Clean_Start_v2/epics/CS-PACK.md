# CS-PACK — 현장·기관 매뉴얼·자료 패키지 제작

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 근거가 있는 콘텐츠를 실행 규칙과 새 공간 식별자로 구조화한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 새 식별자·단위·시간·자격 스키마 / RuleBundle 및 적용성 검수 / 무료 원본 입고 등록 / 새 SiteBundle·관측/가상 분리

**종료 조건:** 같은 이름의 다른 시설·기관을 구별 / 출처의 발견/취득/검사/수용 구분 / 실물 입력이 없는 기술 시험용 콘텐츠를 명확히 표시

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-PACK.01 | 새 공간·기관·시간·데이터 식별자 | IMPLEMENTATION |

| CS-PACK.02 | 기관 매뉴얼을 검수 가능한 규칙으로 구성 | IMPLEMENTATION |

| CS-PACK.03 | 무료 원본 입고와 파일 신뢰경계 | IMPLEMENTATION |

| CS-PACK.04 | 실제 현장 입력·현실 관측 갱신 | IMPLEMENTATION |



## CS-PACK.01 · 새 공간·기관·시간·데이터 식별자

**산출물:** `A-CS-PACK.01` — 새 namespace의 도메인 DTO와 schema·합성 입력

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SiteBundle {id,revision,frames,regions,portals,entities,sourceRefs,qualification}; ScenarioSpec와 OperationalPlan은 별도 revision.

**관련 제품 요구:** REQ-015, REQ-060

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/ContentTypes.cs`
- `Assets/ChooGuard/Content/ContentValidator.cs`
- `content/schemas/site.schema.json`
- `content/schemas/scenario.schema.json`
- `content/fixtures/two-agency.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 stable ID를 발급하고 표시 이름과 분리한다. 구역 수·ID 집합은 실제 목표 범위로 정의하며 과거 ID 목록을 요구하지 않는다.

2. SI 단위, 좌표 frame, simulation tick, event sequence, authored/observed/received 시간을 분리한다.

3. SiteBundle·ScenarioSpec·OperationalPlan의 참조/버전을 검사하고 원본을 immutable로 보관한다.

```

### 정상·반례 시험

**TEST-CS-PACK.01-P / NOT_RUN**

Given 이름이 같고 ID가 다른 두 기관  
When 콘텐츠 등록  
Then 고유 ID로 서로 구분하며 역 이름만으로 병합하지 않는다.

**TEST-CS-PACK.01-N / NOT_RUN**

Given 정의되지 않은 구역 ID 또는 음수 수량  
When 실행 입력 검사  
Then 필드 경로를 포함해 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [STD-JSONLD: JSON-LD 1.1](https://www.w3.org/TR/json-ld11/)

- [STD-PROV: PROV-O](https://www.w3.org/TR/prov-o/)



## CS-PACK.02 · 기관 매뉴얼을 검수 가능한 규칙으로 구성

**산출물:** `A-CS-PACK.02` — RuleBundle과 판본·적용성·예외·검토 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** RuleClause {id,revision,kind,scope,guard,effect,handoff,exception,sourceLocator,review}; DTO는 예외를 검토자료로 유지.

**관련 제품 요구:** REQ-031, REQ-033, REQ-034

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/RuleTypes.cs`
- `Assets/ChooGuard/Content/RuleCatalog.cs`
- `content/schemas/rule.schema.json`
- `content/rules/catalog.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 원문 locator·판본·기관·상황·단위·조건·권한·효과·인계·예외를 필드로 만든다.

2. REQUIRED, DISCRETIONARY, ADVISORY, INVARIANT, UNKNOWN을 구분한다.

3. 승인 주체와 revision 결속이 없는 후보는 official rule로 활성화하지 않는다. 규칙 변경은 의존 초안의 자격만 만료시킨다.

```

### 정상·반례 시험

**TEST-CS-PACK.02-P / NOT_RUN**

Given 검수된 규칙과 특정 기관·상황  
When bundle 활성화  
Then 일치하는 규칙만 실행하고 적용근거를 제공한다.

**TEST-CS-PACK.02-N / NOT_RUN**

Given 판본이 없는 원문 요약  
When 공식 규칙 등록 요청  
Then DRAFT로 남기며 모델이 권한이나 시간을 채우지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-KORAIL: 코레일 재난관리체계](https://info.korail.com/info/contents.do?key=969)

- [MAN-MEDICAL: 재난응급의료 비상대응매뉴얼 개정·배포](https://www.mohw.go.kr/board.es?act=view&bid=0009&list_no=1478957&mid=a10402000000&nPage=1&tag=)

- [MAN-SOP: 소방청 재난현장 표준작전절차 공개 PDF](https://www.daegu.go.kr/cmsh/daegu.go.kr/119/files/%EC%9E%AC%EB%82%9C%ED%98%84%EC%9E%A5%ED%91%9C%EC%A4%80%EC%9E%91%EC%A0%84%EC%A0%88%EC%B0%A8.pdf)



## CS-PACK.03 · 무료 원본 입고와 파일 신뢰경계

**산출물:** `A-CS-PACK.03` — 원본 manifest·비용·형식·hash·입고 상태

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** AssetReceipt {id,sourceUrl,tier,rawHash,formats,rigClips,parts,importStatus,limits}; 실제 바이너리가 없으면 rawHash=null.

**관련 제품 요구:** REQ-062, REQ-063, REQ-064

### 만들 파일과 시험

- `Assets/ChooGuard/Content/AssetIntakeValidator.cs`
- `sources/assets/catalog.json`
- `sources/assets/receipts.schema.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 무료판별 파일 목록을 확인하고 원본은 격리 경로에서 hash·크기·압축경로·실행코드 유무를 검사한다.

2. 페이지 확인과 원본 취득·Unity 임포트·현장 수용을 다른 필드로 둔다.

3. 표현용 기하에서 정원·물성·능력을 추론하지 않는다. 실제 무료 다운로드 상태는 새 환경에서 재확인한다.

```

### 정상·반례 시험

**TEST-CS-PACK.03-P / NOT_RUN**

Given 무료 모델 archive와 취득 영수증  
When 입고 등록  
Then 원문·파일 hash·형식·tier·후속 검사가 분리된다.

**TEST-CS-PACK.03-N / NOT_RUN**

Given archive 안의 경로이탈/임의 DLL  
When 자동 입고  
Then 격리·거부하고 실행하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [FREE-001: Free Low Poly Vehicles Pack](https://rgsdev.itch.io/free-low-poly-vehicles-pack)

- [FREE-010: Animated Men Pack](https://quaternius.com/packs/animatedmen.html)

- [FREE-011: Animated Women Pack](https://quaternius.com/packs/animatedwomen.html)

- [FREE-018: Korean Fire Extinguisher 01](https://polyhaven.com/a/korean_fire_extinguisher_01)

- [MAT-BIPA-BUSAN3: 부산 디지털로케이션 제3구역](https://bwebtoon.com/webtoon-home/core-businesses/digital-location/)

- [MAT-KTX-I: KTX-I OpenBVE 원본](https://haesangang-0317.tistory.com/268)



## CS-PACK.04 · 실제 현장 입력·현실 관측 갱신

**산출물:** `A-CS-PACK.04` — 첫 현장 자료 패키지와 baseline/가상 분리 규칙

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Observation {targetId,observedAt,receivedAt,value,unit,sourceHash,quality}; 현실 자료 없음은 기술 개발의 전역 blocker가 아님.

**관련 제품 요구:** REQ-050

### 만들 파일과 시험

- `content/sites/first-site/source-manifest.json`
- `content/sites/first-site/observation-policy.json`
- `Assets/ChooGuard/Content/RealityBaselineUpdater.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/PACK/Pack04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 허용된 공간·독립 기준 치수·기관 역할·작업시간 근거를 수집하고 관측/문헌/가정을 분리한다.

2. 관측 시간·수신 시간·대상 revision을 검사한다. 역순 갱신은 최신값을 조용히 덮지 않는다.

3. 가상 문 개방·훈련 사건을 실제 시설 관측으로 저장하지 않는다. 갱신한 SiteBundle은 새 revision을 만든다.

```

### 정상·반례 시험

**TEST-CS-PACK.04-P / NOT_RUN**

Given 현재 시설과 이후의 허용된 실제 관측  
When baseline 갱신  
Then 현장 revision과 변경근거가 남고 과거 run은 원 버전을 참조한다.

**TEST-CS-PACK.04-N / NOT_RUN**

Given 운영 플레이의 가상 문 개폐 이벤트  
When 현실 관측으로 주입  
Then 원천 종류 불일치로 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [MAN-KORAIL: 코레일 재난관리체계](https://info.korail.com/info/contents.do?key=969)

- [STD-DTC: Definition of a Digital Twin](https://www.digitaltwinconsortium.org/initiatives/the-definition-of-a-digital-twin/)

- [STD-SOSA: SOSA/SSN](https://www.w3.org/TR/vocab-ssn/)
