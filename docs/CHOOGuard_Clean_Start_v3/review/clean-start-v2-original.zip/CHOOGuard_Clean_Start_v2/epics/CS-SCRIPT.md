# CS-SCRIPT — 선택 운영안의 근거 기반 대본 저작

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 실행 사실과 규칙에서 검토 가능한 대본·실행데이터를 만든다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 근거 조회·권한 제한 AI / ScriptIR·조건부 운영규칙 / native 대본 편집·승인 만료 / 고객양식 출력·의미 변경 회수

**종료 조건:** LLM이 물리/권한/승인을 직접 변경하지 않음 / 대본과 실행형 시나리오 의미 일치 / 외부 서비스 실패에도 수동편집·저장 유지

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-SCRIPT.01 | 허용 근거 조회와 규칙/설명 후보 | IMPLEMENTATION |

| CS-SCRIPT.02 | 조건부 운영안·ScriptIR | IMPLEMENTATION |

| CS-SCRIPT.03 | native 대본 편집·검토 상태 | IMPLEMENTATION |

| CS-SCRIPT.04 | 고객 양식 출력·재로드·수정 회수 | IMPLEMENTATION |



## CS-SCRIPT.01 · 허용 근거 조회와 규칙/설명 후보

**산출물:** `A-CS-SCRIPT.01` — 권한제한 retrieval 및 근거가 결속된 AI 응답

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** AssistantProposal {type,claims,evidenceRefs,missing,patchDraft}; 결정적 상태 계산은 코어 담당.

**관련 제품 요구:** REQ-032, REQ-052, REQ-058, REQ-059

### 만들 파일과 시험

- `Assets/ChooGuard/Authoring/EvidenceQuery.cs`
- `Assets/ChooGuard/Authoring/AssistantGateway.cs`
- `workers/authoring/retrieve.py`
- `workers/authoring/contracts.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-PACK.02.candidate`의 `A-CS-PACK.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.06.candidate`의 `A-CS-OPS.06` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 기관·사건·판본·권한으로 문맥을 좁히고 실제 source locator를 연결한다.

2. AI는 규칙/설명/수정안 후보만 반환한다. 승인·DB쓰기·shell·운영명령 권한은 부여하지 않는다.

3. 문서/메모의 지시문을 데이터로 다루고 비용·timeout·반출 policy를 검사한다. 실패시 수동편집은 계속한다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.01-P / NOT_RUN**

Given 누락값이 있는 원문과 로그  
When 규칙 후보·설명 생성  
Then 미확인과 근거를 표시하고 숫자/기관을 창작하지 않는다.

**TEST-CS-SCRIPT.01-N / NOT_RUN**

Given 원문에 시스템지시처럼 보이는 문장  
When retrieval 처리  
Then 추가 권한이나 실행으로 해석하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SCRIPT.02 · 조건부 운영안·ScriptIR

**산출물:** `A-CS-SCRIPT.02` — 한 실행의 기록을 재사용 가능한 대응 운영규칙으로 저작

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ScriptIR {revision,plan,scenario,steps,roles,conditions,evidence,qualifications}; 내용변경은 새 revision.

**관련 제품 요구:** REQ-051, REQ-053, REQ-054

### 만들 파일과 시험

- `Assets/ChooGuard/Authoring/ScriptCompiler.cs`
- `Assets/ChooGuard/Authoring/ScriptIR.cs`
- `Assets/ChooGuard/Authoring/ScriptSemanticValidator.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SCRIPT.01.candidate`의 `A-CS-SCRIPT.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.02.candidate`의 `A-CS-LAB.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 사실·사후 설명·가설·매뉴얼 근거 제안·검수된 지시를 단계별로 구분한다.

2. 실제 완료시각을 영구적인 정답 시각으로 바꾸지 않고 역할·선행조건·확인·예외로 표현한다.

3. 동일 ScriptIR에서 대본과 실행 데이터를 만들며 존재하지 않는 entity/rule/role을 거부한다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.02-P / NOT_RUN**

Given 선택된 운영안과 대표 실행  
When ScriptIR 생성  
Then 모든 사실은 event, 모든 규범제안은 rule/검수에 연결된다.

**TEST-CS-SCRIPT.02-N / NOT_RUN**

Given 기록 없는 업무를 수행했다고 기술  
When 의미 검사  
Then 근거누락을 반환하고 공식 대본으로 승격하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [REF-MSEL: FEMA Exercise Builder](https://preptoolkit.fema.gov/web/exercise)



## CS-SCRIPT.03 · native 대본 편집·검토 상태

**산출물:** `A-CS-SCRIPT.03` — TMP 편집·변경차이·의미검토·자격 표시

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ReviewDecision {reviewer,role,scope,revision,evidence,time,status}; focus와 UI가 승인권을 부여하지 않음.

**관련 제품 요구:** REQ-055, REQ-056

### 만들 파일과 시험

- `Assets/ChooGuard/Presentation/Authoring/ScriptEditorPresenter.cs`
- `Assets/ChooGuard/Presentation/Authoring/ScriptEditor.prefab`
- `Assets/ChooGuard/Authoring/ReviewLedger.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SCRIPT.02.candidate`의 `A-CS-SCRIPT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PLAY.05.candidate`의 `A-CS-PLAY.05` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. native overlay에서 입력·선택·커서·IME를 유지하고 문장을 누르면 실제 근거를 연다.

2. 서식 변경과 의미 변경을 분리하고 의미 변경은 관련 검토를 만료시킨다.

3. 초안/시뮬레이션사용 검토/기관의 지정훈련 수용은 다른 주체·범위·버전 기록이다. 단어만으로 승인되지 않는다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.03-P / NOT_RUN**

Given 검토된 문서의 의미를 수정  
When 저장  
Then 원 로그 불변, 새 draft revision, 관련 승인 STALE.

**TEST-CS-SCRIPT.03-N / NOT_RUN**

Given AI 텍스트에 승인됨 문구 삽입  
When 표시/저장  
Then qualification 필드는 변경되지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SCRIPT.04 · 고객 양식 출력·재로드·수정 회수

**산출물:** `A-CS-SCRIPT.04` — 문서/실행데이터의 동일 의미와 출력 후 작업 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TemplateProfile {format,revision,fields,exporter,qualification}; 결과는 임의 script를 실행하지 않는다.

**관련 제품 요구:** REQ-086

### 만들 파일과 시험

- `Assets/ChooGuard/Authoring/ExportService.cs`
- `Assets/ChooGuard/Authoring/ImportReconciliation.cs`
- `workers/authoring/export_document.py`
- `content/templates/profiles.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SCRIPT/Script04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SCRIPT.03.candidate`의 `A-CS-SCRIPT.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. JSON·Markdown·DOCX를 공통 IR에서 출력한다. 기관별 다른 형식은 실제 템플릿의 입력/출력 검증 후 활성화한다.

2. 출력 문서와 실행형 구조의 역할·사건·분기·조건을 비교한다.

3. 외부 편집본 의미diff는 수동 또는 지원한 importer로 조정한다. 자동 왕복이 안 되는 형식을 가능한 것으로 표시하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SCRIPT.04-P / NOT_RUN**

Given 같은 ScriptIR와 검증된 TemplateProfile  
When 문서 출력·실행형 재로드  
Then 의미가 일치하고 제한·근거·버전이 포함된다.

**TEST-CS-SCRIPT.04-N / NOT_RUN**

Given 미지원 템플릿 또는 누락된 승인근거  
When 승인본 출력  
Then 지원제한/초안으로 구분하고 실패·수작업을 기록한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `CUSTOMER_WORKFLOW_OR_TEMPLATE` / 요구범위 `CUSTOMER_EFFICACY_OR_FORMAT_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 모집/실제양식 확인 전 고객 효용/지원완료 주장 금지.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-05: HSEEP Design and Development](https://preptoolkit.fema.gov/web/hseep-resources/design-and-development)

- [DISC-07: Exercise Builder](https://preptoolkit.fema.gov/web/exercise)
