# CS-SIM — 다중 물리·행동 계산과 정량 검증

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 운영 판단에 필요한 현상만 검증된 어댑터로 연결한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 격리 worker·기능협상 / 보행/층간 이동 / 접근교통/차량 / 화재/열/연기 기준계산 / 결합·불확도·선택적 가속

**종료 조건:** 수량별 단일 소유자·단위/시간/버전 일치 / 기준모델·최신 후보 공정 비교 / 유효범위 이탈·실패 시 결과를 정상처럼 표시하지 않음

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-SIM.01 | 새 worker 프로토콜·시험 워커 | IMPLEMENTATION |

| CS-SIM.02 | 보행·층간 연결 어댑터 | IMPLEMENTATION |

| CS-SIM.03 | 접근교통·차량 운행 어댑터 | IMPLEMENTATION |

| CS-SIM.04 | 화재·열·연기 기준 계산 | IMPLEMENTATION |

| CS-SIM.05 | 공동시간·불확도·가속·정직한 복구 | IMPLEMENTATION |



## CS-SIM.01 · 새 worker 프로토콜·시험 워커

**산출물:** `A-CS-SIM.01` — 능력협상·취소·재시도·구간결과와 명시적인 시험 워커

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** WorkerCapability, SimulationJob, FieldBatch; 임의 shell 문자열을 입력으로 실행하지 않는다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Contracts/WorkerTypes.cs`
- `Assets/ChooGuard/Simulation/WorkerProcessClient.cs`
- `workers/fixture/worker.py`
- `workers/protocol/worker.schema.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. length-framed JSON 또는 고정 JSONL 프로토콜을 선택해 크기 제한·protocol version·requestId를 검증한다. 로그와 프로토콜 출력 채널을 분리한다.

2. capability에 현상·단위·time-step·batch/interactive·checkpoint·검증영역을 선언한다.

3. worker timeout/exit/corrupt/late result/다른 branch 응답을 검사한다. 시험 워커는 SYNTHETIC_FIXTURE이며 실제 모델로 승격하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.01-P / NOT_RUN**

Given 유효한 job·시험 worker  
When 요청·결과 적용  
Then hash·run·boundary·시간 검사가 일치한 결과만 반환한다.

**TEST-CS-SIM.01-N / NOT_RUN**

Given 다른 run의 늦은 응답 또는 과대 payload  
When 수신  
Then 거부하고 현재 run을 변경하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SIM.02 · 보행·층간 연결 어댑터

**산출물:** `A-CS-SIM.02` — 현상별 비교 가능한 사람 이동과 보조 이동 계약

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** PedestrianState {entityId,frameId,position,velocity,tick,modelRef}; 독립 관측 전에는 현장 정확도 미판정.

**관련 제품 요구:** REQ-019, REQ-043

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/PedestrianAdapter.cs`
- `workers/pedestrian/runner.py`
- `benchmarks/pedestrian/protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.02.candidate`의 `A-CS-WORLD.02` → 이 작업 `qualification`. 조건: `NAMED_SITE_ACCURACY`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. JuPedSim 등의 기준·후보를 동일 geometry·독립 현상 데이터로 비교한다.

2. 위치의 정본은 한 엔진에만 둔다. Unity의 표시·회피 로직과 이중 소유하지 않는다.

3. 계단/승강기/보조 이동은 지원 범위를 별도 기술하고 기본 보행모델의 정확도를 자동 상속하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.02-P / NOT_RUN**

Given 검수된 병목 fixture와 기준 관측  
When 후보 실행  
Then 통과량·위치·대기분포·실패 범위를 기록한다.

**TEST-CS-SIM.02-N / NOT_RUN**

Given 미지원 층간 이동  
When 경로/수량 평가  
Then UNSUPPORTED와 적용 제외 범위를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-JPS14: JuPedSim v1.4.0 release announcement](https://github.com/PedestrianDynamics/jupedsim/discussions/1567)

- [TECH-JUPED: JuPedSim 보행 모델](https://www.jupedsim.org/stable/pedestrian_models/)

- [TECH-PEDDATA: Jülich Fair2Ped·보행 실험 아카이브](https://www.fz-juelich.de/en/ias/ias-7/research-1/projects/fair2ped-1)



## CS-SIM.03 · 접근교통·차량 운행 어댑터

**산출물:** `A-CS-SIM.03` — 지도밖 도착 가정과 정량 교통모델의 구분

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** TrafficState {vehicleId,crewIds,routeId,frameId,tick,provenance}; 철도 운행은 충돌/탈선 동역학과 다름.

**관련 제품 요구:** REQ-044

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/TrafficAdapter.cs`
- `workers/traffic/runner.py`
- `benchmarks/traffic/protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. SUMO 등 후보에 현지 경로·가용성·차량·운행조건을 결속한다.

2. 정량 프로파일에서는 teleport·숨은 우회 등을 탐지하고 해당 실행의 자격을 제한한다.

3. 해당 QoI가 필요 없는 과제는 명시적 도착 시나리오 입력을 쓸 수 있지만 실제 출동시간 예측으로 부르지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.03-P / NOT_RUN**

Given 현지 조건과 이동 fixture  
When 접근시간 계산  
Then 입력·모델·shortcut 여부·오차 근거가 남는다.

**TEST-CS-SIM.03-N / NOT_RUN**

Given silent teleport 또는 없는 연결  
When 출동시간 출력  
Then 정상 예측 자격을 보류하고 근거를 남긴다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-SUMO: SUMO 긴급차량 모델](https://sumo.dlr.de/docs/Simulation/Emergency.html)

- [TECH-SUMO-RAIL: SUMO 철도 모델](https://sumo.dlr.de/docs/Simulation/Railways.html)



## CS-SIM.04 · 화재·열·연기 기준 계산

**산출물:** `A-CS-SIM.04` — 실제 geometry/material/boundary와 FDS 기준 결과

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** HazardRun {inputHash,solverLock,boundaryHistory,grid,qoi,resultRefs,validation}; 실제 관측없는 기준계산 일치는 현실 검증이 아님.

**관련 제품 요구:** REQ-042

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/HazardReferenceAdapter.cs`
- `workers/hazard/reference_runner.py`
- `benchmarks/hazard/reference-protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-WORLD.02.candidate`의 `A-CS-WORLD.02` → 이 작업 `qualification`. 조건: `NAMED_SITE_ACCURACY`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 고정된 FDS 실행 버전과 물성·형상·개구·열원·경계·관측을 검사한다.

2. 기본 경로는 batch reference이며 live rollback을 지원한다고 가정하지 않는다. 수렴·독립 데이터·QoI를 별도 평가한다.

3. 필요 기준을 실행 전에 고정한다. 영상 전환·VFX를 온도/농도 데이터로 사용하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.04-P / NOT_RUN**

Given 검토된 기준실험과 input deck  
When solver 실행·대조  
Then 수치수렴·오차·적용범위·원시 결과를 납품한다.

**TEST-CS-SIM.04-N / NOT_RUN**

Given 물성이 없거나 폭발 충격파를 요청  
When 정량 평가  
Then 입력/현상 범위 불충족으로 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-FDS: FDS 매뉴얼·검증 안내](https://pages.nist.gov/fds-smv/manuals.html)

- [TECH-FDS-SCOPE: FDS 범위 및 FDS+Evac 지원 상태](https://pages.nist.gov/fds-smv/)



## CS-SIM.05 · 공동시간·불확도·가속·정직한 복구

**산출물:** `A-CS-SIM.05` — 선택한 worker들이 같은 경계에서 작동하는 결합과 model qualification

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** CommittedBoundary {tick,sequence,inputs,fieldOwners,resultHashes,capabilities}; 독립 reference/모델 결과는 runtime schema와 별도로 qualification.

**관련 제품 요구:** REQ-035, REQ-046, REQ-047, REQ-048, REQ-049

### 만들 파일과 시험

- `Assets/ChooGuard/Simulation/CosimulationCoordinator.cs`
- `Assets/ChooGuard/Simulation/QuantityOwnership.cs`
- `Assets/ChooGuard/Simulation/ModelQualification.cs`
- `workers/hazard/surrogate_runner.py`
- `benchmarks/coupling/protocol.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SIM/Sim05Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.01.candidate`의 `A-CS-LAB.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SIM.02.candidate`의 `A-CS-SIM.02` → 이 작업 `qualification`. 조건: `PEDESTRIAN_QOI`.

- `CS-SIM.03.candidate`의 `A-CS-SIM.03` → 이 작업 `qualification`. 조건: `TRAFFIC_QOI`.

- `CS-SIM.04.candidate`의 `A-CS-SIM.04` → 이 작업 `qualification`. 조건: `HAZARD_QOI`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. run에서 사용하는 worker만 참여시켜 시간·단위·좌표·수량별 writer와 불연속 사건 동기화를 검사한다.

2. required worker 결과가 실패하면 경계를 commit하지 않는다. 복원이 안 되면 공통 유효 checkpoint/시작 상태부터 재계산한다.

3. 선택적 ROM/PhysicsNeMo 후보는 기준·관측·독립 형상에서 장기 roll-out·보존량·OOD를 검사한다. 가속모델이 없다는 이유로 필수 reference 경로를 삭제하지 않는다.

4. 훈련/비교에 쓰는 QoI가 요구하는 현상만 설치하되, 중요한 물리를 제외하고 정확도 주장을 유지하지 않는다.

```

### 정상·반례 시험

**TEST-CS-SIM.05-P / NOT_RUN**

Given 동일 문 이벤트가 이동·위험장에 영향  
When 공통 경계 적용  
Then 버전·tick·boundary가 일치하며 허용된 결합 오차를 보고한다.

**TEST-CS-SIM.05-N / NOT_RUN**

Given partial worker advance 후 장애 또는 OOD  
When 계산 지속 요청  
Then 묵시적 저정밀 대체 없이 대기/재계산/자격 보류를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [STD-FMI: FMI 3.0.2](https://fmi-standard.org/docs/3.0.2/)

- [TECH-MAPANYTHING: MapAnything: Universal Feed-Forward Metric 3D Reconstruction](https://github.com/facebookresearch/map-anything)

- [TECH-PHYSICSNEMO: NVIDIA PhysicsNeMo](https://docs.nvidia.com/physicsnemo/latest/index.html)
