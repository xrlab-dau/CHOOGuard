# CS-WORLD — 현실 기반 철도 운영 공간

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 맵의 시각·이동·계산·의미 표현을 새로 구축한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 기술 fixture / 실제 첫 연결 구간·무료 자산 / 개체 anchor·상태 투영 / 구역 준비·로딩·차량 연결

**종료 조건:** 첫 현장의 근거/가정 분리 / 카메라·LOD가 운영결과를 바꾸지 않음 / 필요한 상태가 준비되기 전 잘못된 공간 진입 없음

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-WORLD.01 | 처음부터 만드는 2공간·문 fixture | IMPLEMENTATION |

| CS-WORLD.02 | 첫 철도 공간과 무료 시각자산 제작 | IMPLEMENTATION |

| CS-WORLD.03 | 운영 객체·월드마커·층별 보기 | IMPLEMENTATION |

| CS-WORLD.04 | 구역 준비·로딩·차량 프레임 연결 | IMPLEMENTATION |



## CS-WORLD.01 · 처음부터 만드는 2공간·문 fixture

**산출물:** `A-CS-WORLD.01` — 신규 scene·entity anchors·합성 공간 입력

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** WorldAnchorMap {entityId,transformRef,frameId,representationKind}; Unity Transform은 표시 수단.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/World/FixtureBuilder.cs`
- `Assets/ChooGuard/World/WorldEntityAnchor.cs`
- `Assets/ChooGuard/Scenes/OperationsFixture.unity`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.02.candidate`의 `A-CS-BOOT.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 1m 비대칭 기준체와 두 공간·문 하나를 새 Scene에 만든다. 모든 고유 ID는 현 기준에서 발급한다.

2. visual/collider/navigation/semantic 레이어를 분리한다. 문 열림은 도메인 projection을 받아 표시한다.

3. 실측 부산역으로 표시하지 않고 SYNTHETIC_FIXTURE 라벨을 붙인다. 초기 fixture는 실제 자료 취득을 기다리지 않는다.

```

### 정상·반례 시험

**TEST-CS-WORLD.01-P / NOT_RUN**

Given 새 프로젝트와 fixture builder  
When 생성·reload  
Then ID가 중복되지 않고 문·두 공간과 단위가 재현된다.

**TEST-CS-WORLD.01-N / NOT_RUN**

Given 같은 entityId를 두 anchor에 사용  
When 검사  
Then 정확 경로를 반환하며 로드를 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-WORLD.02 · 첫 철도 공간과 무료 시각자산 제작

**산출물:** `A-CS-WORLD.02` — 외부 도착–맞이방–승강장–객실의 입고·정합 산출물

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** GeometryReceipt {assetId,sourceHash,transform,units,parts,residuals,scope}; 실제 맵 수용에는 현장 입력이 추가로 필요.

**관련 제품 요구:** REQ-014, REQ-017, REQ-018

### 만들 파일과 시험

- `Assets/ChooGuard/World/AssetImportPolicy.cs`
- `Assets/ChooGuard/World/CoordinateValidator.cs`
- `Assets/ChooGuard/Art/first-site.asset-manifest.json`
- `content/sites/first-site/geometry.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.03.candidate`의 `A-CS-PACK.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.04.candidate`의 `A-CS-PACK.04` → 이 작업 `qualification`. 조건: `NAMED_SITE_ACCURACY`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 무료 원본을 하나씩 격리 임포트하여 단위·축·rig·clip·문 피벗·LOD·재질·충돌을 검사한다.

2. 핵심 공간은 실제 자료의 근거별로 제작하고 신경복원 후보는 COLMAP 대조와 독립 치수를 함께 사용한다.

3. 관측 부족이면 합성/추정 표현과 필요한 입력을 분리한다. 독립 치수 없이 신경망 confidence를 실측 정확도로 쓰지 않는다.

```

### 정상·반례 시험

**TEST-CS-WORLD.02-P / NOT_RUN**

Given 원본과 단위/독립 치수 근거  
When 첫 구간 제작·정합  
Then 허용 오차·잔차·변환행렬·자료 상태를 함께 납품한다.

**TEST-CS-WORLD.02-N / NOT_RUN**

Given 원본에는 mm인데 m로 임포트 또는 다른 역 자료  
When 입고 검증  
Then 축척/대상 불일치로 정량 사용을 보류한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

- `FIELD_DATA_AND_INDEPENDENT_REFERENCE` / 요구범위 `NAMED_SITE_QUANTITATIVE_OR_FIELD_CLAIM` / `NOT_VERIFIED_IN_NEW_BASELINE`. 해당 주장/검수만 제한하며 기술 fixture 개발을 전역 차단하지 않는다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [FREE-001: Free Low Poly Vehicles Pack](https://rgsdev.itch.io/free-low-poly-vehicles-pack)

- [FREE-003: Train Kit](https://kenney.nl/assets/train-kit)

- [FREE-018: Korean Fire Extinguisher 01](https://polyhaven.com/a/korean_fire_extinguisher_01)

- [MAT-BIPA-BUSAN3: 부산 디지털로케이션 제3구역](https://bwebtoon.com/webtoon-home/core-businesses/digital-location/)

- [MAT-KTX-I: KTX-I OpenBVE 원본](https://haesangang-0317.tistory.com/268)

- [TECH-MAPANYTHING: MapAnything: Universal Feed-Forward Metric 3D Reconstruction](https://github.com/facebookresearch/map-anything)

- [TECH-UNITY-FBX: Unity model formats](https://docs.unity3d.com/6000.3/Documentation/Manual/3D-formats.html)



## CS-WORLD.03 · 운영 객체·월드마커·층별 보기

**산출물:** `A-CS-WORLD.03` — 같은 ID의 3D 표시와 운영 projection 연결

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SessionProjection {runId,revision,viewScope,entities,reasons}; 표현 계층은 domain 상태를 직접 쓰지 않는다.

**관련 제품 요구:** REQ-016

### 만들 파일과 시험

- `Assets/ChooGuard/World/WorldProjectionApplier.cs`
- `Assets/ChooGuard/World/WorldMarkerPool.cs`
- `Assets/ChooGuard/World/FloorVisibility.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-WORLD.01.candidate`의 `A-CS-WORLD.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.01.candidate`의 `A-CS-OPS.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 최신 run/revision의 projection만 main thread에 반영한다. 다른 branch 결과를 적용하지 않는다.

2. 층·지붕·거리 LOD는 renderer만 바꾸고 물리/예약/지식은 바꾸지 않는다.

3. marker는 선택 우선으로 풀링하고 카메라 뒤/다른 층/기관 정보 범위를 처리한다.

```

### 정상·반례 시험

**TEST-CS-WORLD.03-P / NOT_RUN**

Given 동일 운영입력과 다른 카메라·층 보기  
When 상태 비교  
Then UI 표시 외 의미 상태는 동일하다.

**TEST-CS-WORLD.03-N / NOT_RUN**

Given 이전 branch projection 도착  
When 화면 반영  
Then 거부/무시하고 최신 상태를 유지한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-UNITY-LOAD: Unity LoadSceneAsync](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/SceneManagement.SceneManager.LoadSceneAsync.html)



## CS-WORLD.04 · 구역 준비·로딩·차량 프레임 연결

**산출물:** `A-CS-WORLD.04` — 상태를 잃지 않는 구역 및 정차 차량 연결 계약

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** RegionReadiness {regionId,visual,collision,path,state}; DockLink {vehicleFrame,siteFrame,stopConfirmed,doorState}.

**관련 제품 요구:** REQ-020

### 만들 파일과 시험

- `Assets/ChooGuard/World/RegionLoader.cs`
- `Assets/ChooGuard/World/RegionReadiness.cs`
- `Assets/ChooGuard/World/VehicleFrameBinding.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/WORLD/World04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-WORLD.03.candidate`의 `A-CS-WORLD.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 작은 구간은 통째로 로드하며 확장시 additive loading을 적용한다. logical lifetime은 Scene과 분리한다.

2. 진입은 collision·경로·필수 state가 준비된 경우에만 허용한다. 로딩 실패는 해당 구간만 표시한다.

3. 정차·도킹·문 상태를 연결하며 객실 local frame과 현장 frame의 변환을 검증한다. 운행 범위는 별도 capability로 선언한다.

```

### 정상·반례 시험

**TEST-CS-WORLD.04-P / NOT_RUN**

Given 필수 데이터가 준비된 연결 구간  
When 진입·왕복·표시 unload  
Then 개체/예약/업무가 유지된다.

**TEST-CS-WORLD.04-N / NOT_RUN**

Given 차량 frame 누락 또는 바닥 미준비  
When 연결 통과  
Then 잘못된 진입을 막고 정상 구간 상태는 보존한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [TECH-UNITY-LOAD: Unity LoadSceneAsync](https://docs.unity3d.com/6000.3/Documentation/ScriptReference/SceneManagement.SceneManager.LoadSceneAsync.html)
