# CS-LAB — 저장된 운영안의 분기·비교 실험

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 동일 입력에서 운영 대안을 재현·수정·비교한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 완전 checkpoint·replay / 불변 분기와 복원가능성 / 공정한 반복 A/B / 변경영향·부분 재계산

**종료 조건:** 불완전 snapshot을 정확 분기로 표시하지 않음 / 내생 결과를 두 안에 강제 복사하지 않음 / 우열 불명·실패·미완료를 보존

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-LAB.01 | 이벤트 재생·완전 checkpoint | IMPLEMENTATION |

| CS-LAB.02 | 원본 불변 분기·재실행 | IMPLEMENTATION |

| CS-LAB.03 | 동일조건·불확도·비지배 비교 | IMPLEMENTATION |

| CS-LAB.04 | 변경 영향·캐시·부분 재실행 | IMPLEMENTATION |



## CS-LAB.01 · 이벤트 재생·완전 checkpoint

**산출물:** `A-CS-LAB.01` — 예약/메시지/난수/worker 상태를 담은 snapshot

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Checkpoint {runId,cutSeq,simTick,contentHashes,domain,random,workers,capabilities}; renderer state는 선택적.

**관련 제품 요구:** REQ-036

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/CheckpointService.cs`
- `Assets/ChooGuard/Experiments/ReplayReader.cs`
- `Assets/ChooGuard/Experiments/CheckpointManifest.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-OPS.02.candidate`의 `A-CS-OPS.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-OPS.05.candidate`의 `A-CS-OPS.05` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-SIM.01.candidate`의 `A-CS-SIM.01` → 이 작업 `qualification`. 조건: `EXTERNAL_WORKER_USED`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 공통 cut에서 업무·예약·기관지식·미전달 메시지·난수·worker 상태 또는 재계산 recipe를 모은다.

2. 필수 worker 목록은 capability와 run config에서 구한다. 파일 이름 존재만으로 정확 복원을 허용하지 않는다.

3. hash·version·시간을 검증한 후 manifest를 durable로 게시한다. 누락되면 복구 제한을 명시한다.

```

### 정상·반례 시험

**TEST-CS-LAB.01-P / NOT_RUN**

Given 전달중 메시지와 예약이 있는 run  
When snapshot·restore  
Then 의미상태와 미래 사건 순서가 지정 기준 내 일치한다.

**TEST-CS-LAB.01-N / NOT_RUN**

Given 필수 worker 내부 상태 누락  
When 정확 restore 요청  
Then 거부하고 검증된 checkpoint/처음부터 재계산 경로를 표시한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-LAB.02 · 원본 불변 분기·재실행

**산출물:** `A-CS-LAB.02` — parent-run/checkpoint가 연결된 새 실행

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** BranchReceipt {newRunId,parentRunId,checkpointHash,kind,changedPlan}; 리플레이는 새 실험이 아니다.

**관련 제품 요구:** REQ-037, REQ-057

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/BranchService.cs`
- `Assets/ChooGuard/Experiments/BranchLineage.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-LAB.01.candidate`의 `A-CS-LAB.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 runId와 parent checkpoint reference를 만들고 원래 run을 갱신하지 않는다.

2. 지원하는 정확 복원과 새 초기화 실행을 구별한다. user note는 과거 원래 의도로 덮어쓰지 않는다.

3. 불완전 복원 capability이면 특정 시점 branch를 비활성화하고 다른 시작점을 명시한다.

```

### 정상·반례 시험

**TEST-CS-LAB.02-P / NOT_RUN**

Given 완전 snapshot A  
When B 분기 후 배정 수정  
Then A 이벤트 hash가 불변이고 B 변경이 독립으로 남는다.

**TEST-CS-LAB.02-N / NOT_RUN**

Given checkpoint 파일 한 개 손상  
When branch 생성  
Then 정확분기 거부와 손상 파일 근거를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-LAB.03 · 동일조건·불확도·비지배 비교

**산출물:** `A-CS-LAB.03` — 의도적으로 고정한 외생조건과 조건별 비교 보고

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Comparison {basis,inputs,qoi,violations,uncertainty,status,selectionReason}; 현실 전체 최적을 주장하지 않음.

**관련 제품 요구:** REQ-038, REQ-039

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/ComparisonService.cs`
- `Assets/ChooGuard/Experiments/ExogenousScenarioStreams.cs`
- `Assets/ChooGuard/Experiments/ComparisonReport.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-LAB.02.candidate`의 `A-CS-LAB.02` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. map/rule/model/QoI basis가 호환되는지 먼저 검사한다. 외생 난수 혁신은 stable process key로 결속한다.

2. 사용자 조치가 바꾸는 후속 이동·보고·혼잡은 각 run에서 다시 계산한다.

3. 제약 위반을 속도 점수로 상쇄하지 않는다. 불확도·실패·우열 불명과 다목적 비지배 대안을 표시한다.

```

### 정상·반례 시험

**TEST-CS-LAB.03-P / NOT_RUN**

Given 같은 외부 조건과 다른 배정안  
When paired 비교  
Then 공통조건과 달라진 내생 결과가 구별된다.

**TEST-CS-LAB.03-N / NOT_RUN**

Given 다른 모델 버전 또는 평가범위  
When 전체 순위 계산  
Then 공통 가능 수량만 비교하거나 전체 비교 불가를 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-LAB.04 · 변경 영향·캐시·부분 재실행

**산출물:** `A-CS-LAB.04` — 정확성 조건을 가진 빠른 반복 실험

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** Impact {changedInputs,dirtyOutputs,evidence,allowedReuse,requiredRecompute}; 관계 부재는 영향 없음이 아님.

**관련 제품 요구:** REQ-084

### 만들 파일과 시험

- `Assets/ChooGuard/Experiments/ImpactGraph.cs`
- `Assets/ChooGuard/Experiments/ReplayCache.cs`
- `Assets/ChooGuard/Experiments/RunInvalidation.cs`

- 검사: `Assets/ChooGuard/Tests/EditMode/LAB/Lab04Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-LAB.03.candidate`의 `A-CS-LAB.03` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 표현/서식 변경과 의미/물리 입력 변경을 구분한다.

2. 입력·버전·설정 hash와 영향 경계를 입증할 수 있을 때만 파생결과를 재사용한다.

3. 영향이 누락됐거나 비선형 파급을 제한할 수 없으면 확대 재계산한다. 과거 증거를 삭제하지 않고 현재 사용 자격을 STALE로 둔다.

```

### 정상·반례 시험

**TEST-CS-LAB.04-P / NOT_RUN**

Given 영향경계가 검증된 배정 변경  
When 부분과 전체 재계산 대조  
Then 동일 QoI/의미상태가 사전 허용범위 내다.

**TEST-CS-LAB.04-N / NOT_RUN**

Given 영향 그래프에 없는 물리 경계변경  
When 캐시 재사용  
Then 재사용을 거부하고 넓은 재계산을 요구한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.
