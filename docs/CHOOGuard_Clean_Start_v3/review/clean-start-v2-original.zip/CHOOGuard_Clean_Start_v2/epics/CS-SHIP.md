# CS-SHIP — 로컬 배포·복구·현장 확장

> 새 구축 에픽. 빈 Unity 프로젝트를 위한 구현 명세이며 제품 구현·시험 완료가 아니다.

**목표:** 오프라인 사용과 갱신·복구·추가 현장을 반복 가능한 제품으로 인계한다.

**입력 문서:** [제품 기준](../PRODUCT_BASELINE.md) · [신규 공통 계약](../CONTRACTS.md)

**포함:** 실행파일·번들·모델 설치 / 백업·업그레이드·보관·외부전송 정책 / 새 구역/기관/유형 확장·비용

**종료 조건:** 깨끗한 PC에서 승인 범위 실행 / 복구 시 receipt/예약/실행 혈통 보존 / 새 현장의 기존 검증 자동 상속 금지

**범위 밖:** 다른 모듈의 상태를 직접 수정하거나 미검증 결과를 현장 승인으로 바꾸지 않는다. 원격 쓰기·개인 배정은 이 명세가 수행하지 않는다.

## 작업 목록

| 작업 | 검수 가능한 결과 | 경로 |

|---|---|---|

| CS-SHIP.01 | 오프라인 제품 묶음·업데이트 | IMPLEMENTATION |

| CS-SHIP.02 | 백업·스키마 갱신·장애 복구 | IMPLEMENTATION |

| CS-SHIP.03 | 새 현장·기관·사건 확장과 운영 인계 | IMPLEMENTATION |



## CS-SHIP.01 · 오프라인 제품 묶음·업데이트

**산출물:** `A-CS-SHIP.01` — PC 실행파일·native UI·필요 모델·번들·출력기 설치

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** ProductManifest {buildLock,contentRefs,modelRefs,capabilities,qualification}; 구매승인은 개발선행이 아님.

**관련 제품 요구:** REQ-073, REQ-087

### 만들 파일과 시험

- `packaging/product-manifest.json`
- `scripts/release/Build-Installer.ps1`
- `packaging/update-policy.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SHIP/Ship01Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-BOOT.03.candidate`의 `A-CS-BOOT.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.02.candidate`의 `A-CS-PROOF.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.04.candidate`의 `A-CS-PROOF.04` → 이 작업 `qualification`. 조건: `CLAIM_FIELD_USE`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 source와 dependency lock·모델/콘텐츠 hash를 결속하고 개인정보·키·제한원본을 제외한다.

2. 원격AI·외부 worker는 승인된 환경에서만 사용하고 오프라인은 가용계산·저장·수동편집을 유지한다.

3. 기술 배포와 현장용 qualification을 구별하여 미검증 표식이 설치과정에서 사라지지 않게 한다.

```

### 정상·반례 시험

**TEST-CS-SHIP.01-P / NOT_RUN**

Given 깨끗한 PC와 네트워크 차단  
When 설치·실행·저장·편집  
Then 로컬 지원기능이 작동하고 미지원 부분을 표시한다.

**TEST-CS-SHIP.01-N / NOT_RUN**

Given 필수 번들 hash 불일치  
When 제품 시작  
Then 정합성 오류로 해당 실행을 막고 원인을 반환한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SHIP.02 · 백업·스키마 갱신·장애 복구

**산출물:** `A-CS-SHIP.02` — 새 제품 내부에서의 안전한 저장형식 갱신과 restore

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** BackupManifest {cut,dbHash,blobHashes,schema,format,scope}; 삭제는 별도 명시된 운영정책에 따른다.

**관련 제품 요구:** 새 구현 기반 계약. 담당 에픽의 기능에 필요한 기반.

### 만들 파일과 시험

- `Assets/ChooGuard/Persistence/BackupService.cs`
- `Assets/ChooGuard/Persistence/SchemaUpgrade.cs`
- `packaging/restore-policy.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SHIP/Ship02Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SHIP.01.candidate`의 `A-CS-SHIP.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-LAB.01.candidate`의 `A-CS-LAB.01` → 이 작업 `integration`. 조건: `ALWAYS`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. DB와 blob/checkpoint 참조를 일관된 cut으로 백업하고 누락·손상을 검사한다.

2. 이후 새 제품의 schema version 간 업그레이드는 별도 백업·검증·rollback 경로로 수행한다. 이는 초기화 이전 제품 호환을 뜻하지 않는다.

3. 복구후 receipt·예약·outbox·lineage를 검사한다. 해시는 동일성 검사용이며 기관 승인을 증명하는 서명이 아니다.

```

### 정상·반례 시험

**TEST-CS-SHIP.02-P / NOT_RUN**

Given 정상 백업과 지원하는 새 제품 버전  
When restore  
Then 같은 durable cut과 자원 보존을 확인한다.

**TEST-CS-SHIP.02-N / NOT_RUN**

Given 누락된 blob 또는 지원불가 schema  
When 업그레이드/복원  
Then 원본 보존·미지원 보고하며 자동 파괴하지 않는다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.



## CS-SHIP.03 · 새 현장·기관·사건 확장과 운영 인계

**산출물:** `A-CS-SHIP.03` — 데이터 중심 확장과 책임·반복비용 기록

**상태:** SPECIFIED_NOT_IMPLEMENTED / 인수시험 NOT_RUN

**입출력:** SiteRegistry+ReleaseScope; 물리·기관 수용은 그 범위의 별도 근거로 결속한다.

**관련 제품 요구:** REQ-075, REQ-088, REQ-091

### 만들 파일과 시험

- `content/releases/site-registry.json`
- `packaging/operations-handbook.md`
- `research/adoption/maintenance-ledger.json`

- 검사: `Assets/ChooGuard/Tests/EditMode/SHIP/Ship03Tests.cs`

경로는 새 저장소에서 만들 대상이다. 이 문서 ZIP에 제품 C#·Scene·Asset을 이미 구축한 것이 아니다.

### 산출물 의존성

- `CS-SHIP.02.candidate`의 `A-CS-SHIP.02` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PACK.01.candidate`의 `A-CS-PACK.01` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-MODES.03.candidate`의 `A-CS-MODES.03` → 이 작업 `integration`. 조건: `ALWAYS`.

- `CS-PROOF.04.candidate`의 `A-CS-PROOF.04` → 이 작업 `qualification`. 조건: `CLAIM_FIELD_USE`.

새 public contract가 준비되면 명시적인 test double로 unit 개발 가능. dependsOn은 해당 integration/qualification 단계의 실제 산출물을 요구한다.

### 구현 알고리즘

```text

1. 새 지역/구역/기관 ID를 등록한다. 특정 과거 구역 수나 ID 대응을 강제하지 않는다.

2. 새 현장의 geometry·rules·model scope를 별도로 검토하고 기존 정확도를 자동 복사하지 않는다.

3. 설정/콘텐츠 변경과 코어코드 변경 비용, 유지보수 책임·관심/파일럿/구매를 구분해 남긴다.

```

### 정상·반례 시험

**TEST-CS-SHIP.03-P / NOT_RUN**

Given 새 현장 bundle과 독립 검수 범위  
When 확장 납품  
Then 코어 재작성 필요 여부와 해당 범위 자격·수동작업이 보인다.

**TEST-CS-SHIP.03-N / NOT_RUN**

Given 다른 역 bundle에 기존 현장 승인 재사용  
When 수용 요청  
Then 범위 불일치로 거부한다.

### 인계와 거부

실제 새 commit·입출력 hash·명령·환경·원시 결과·실패/미실행·현재 장애를 반환한다. 단위시험 test double 성공은 실제 워커·현장 통합 통과가 아니다. 필수 데이터가 없으면 영향받는 qualification만 보류한다.

### 원문 후보 — 이번 작업에서 새 취득·현행성 검증을 하지 않음

- [DISC-02: 2025년 상반기 안전한국훈련 실시](https://www.mois.go.kr/frt/bbs/type010/commonSelectBoardArticle.do?bbsId=BBSMSTR_000000000008&nttId=117612)

- [DISC-04: 메타버스에서 철도안전 미래 다져](https://www.srail.or.kr/cms/article/view.do?pageId=KR0502000000&postNo=1361)

- [DISC-07: Exercise Builder](https://preptoolkit.fema.gov/web/exercise)

- [DISC-08: AI Assistance](https://www.conducttr.com/ai-assistance)

- [DISC-09: The XVR Platform](https://www.xvrsim.com/en/platform/)

- [DISC-10: Virtual Reality Incident Command Training](https://www.dcc.edu/workforce-development/maritime/virtual-reality-training.aspx)
